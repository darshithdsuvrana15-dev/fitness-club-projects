<?php
include 'connection.php';

$today = date('Y-m-d');

// Get all users
$users = mysqli_query($conn, "SELECT id FROM users");
while ($user = mysqli_fetch_assoc($users)) {
    $uid = $user['id'];

    // Check if this user has already marked attendance today
    $check = mysqli_query($conn, "SELECT id FROM gym_attendance WHERE user_id = $uid AND attendance_date = '$today'");

    if (mysqli_num_rows($check) == 0) {
        // Insert absent record
        mysqli_query($conn, "INSERT INTO gym_attendance (user_id, attendance_date, status) VALUES ($uid, '$today', 'Absent')");
    }
}
echo "Absentees marked.";
?>
