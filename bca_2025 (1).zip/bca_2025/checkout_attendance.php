<?php
include 'connection.php';


$user_id = isset($_POST['user_id']) ? $_POST['user_id'] : null;
$msg = '';

if ($user_id) {
    $today = date('Y-m-d');
    $checkout_time = date('H:i:s');

    // Check if the user already has a check-in record today
    $check = mysqli_query($conn, "SELECT * FROM gym_attendance WHERE user_id = $user_id AND attendance_date = '$today'");

    if (mysqli_num_rows($check) > 0) {
        // Update check_out_time
        $update = mysqli_query($conn, "
            UPDATE gym_attendance 
            SET check_out_time = '$checkout_time' 
            WHERE user_id = $user_id AND attendance_date = '$today'
        ");

        if ($update) {
            $msg = "Check-out time updated!";
        } else {
            $msg = "Error updating check-out time.";
        }
    } else {
        $msg = "No check-in found for today.";
    }
} else {
    $msg = "User ID missing.";
}

// Redirect with message
header("Location: attendance.php?message=" . urlencode($msg));
exit;
?>
