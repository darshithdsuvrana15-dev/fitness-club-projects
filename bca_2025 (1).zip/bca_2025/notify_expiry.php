<?php
require_once 'connection.php';

$today = date('Y-m-d');
$notify_date = date('Y-m-d', strtotime('+2 days'));

$query = "SELECT u.name, u.email, p.end_date
          FROM (
              SELECT user_id, MAX(end_date) AS end_date
              FROM payments
              GROUP BY user_id
          ) latest
          JOIN payments p ON p.user_id = latest.user_id AND p.end_date = latest.end_date
          JOIN users u ON u.id = p.user_id
          WHERE p.end_date = ?";
          
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $notify_date);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $email = $row['email'];
    $end_date = $row['end_date'];

    $emailData = [
        'sender' => ['name' => 'FITNESS CLUB', 'email' => 'thusharshettigar7483@gmail.com'],
        'to' => [['email' => $email, 'name' => $name]],
        'subject' => 'Your Gym Subscription is Expiring Soon',
        'htmlContent' => "<p>Dear $name,<br><br>Your gym subscription is expiring on <strong>$end_date</strong>. Please renew it to continue your fitness journey without interruption.<br><br>Regards,<br>Fitness Club</p>"
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.brevo.com/v3/smtp/email");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($emailData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'accept: application/json',
        'api-key: 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',
        'content-type: application/json',
    ]);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // Determine status
    $status = ($curl_error || $http_code >= 400) ? 'failed' : 'sent';
    $responseText = $curl_error ? $curl_error : $response;

    $type = 'EXPIRE';

    // Insert into email_logs
    $logQuery = "INSERT INTO email_logs (user_email, user_name, type, status, response) 
                VALUES (?, ?, ?, ?, ?)";
    $logStmt = $conn->prepare($logQuery);
    $logStmt->bind_param("sssss", $email, $name, $type, $status, $responseText);
    $logStmt->execute();
    $logStmt->close();


}

$stmt->close();
$conn->close();
?>
