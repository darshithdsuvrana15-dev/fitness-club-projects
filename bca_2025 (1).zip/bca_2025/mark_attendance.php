<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $today = date('Y-m-d');
    $time = date('H:i:s');
    $msg = '';

    // Check if already marked
    $check = mysqli_query($conn, "SELECT * FROM gym_attendance WHERE user_id = $user_id AND attendance_date = '$today'");

    if (mysqli_num_rows($check) == 0) {
        $query = "INSERT INTO gym_attendance (user_id, attendance_date, check_in_time) VALUES ($user_id, '$today', '$time')";
        if (mysqli_query($conn, $query)) {
            $msg = "Attendance marked!";
        } else {
            $msg = "Error marking attendance.";
        }
    } else {
        $msg = "Attendance already marked for today.";
    }

    // Redirect with message
    header("Location: attendance.php?message=" . urlencode($msg));
    exit;
}
?>
