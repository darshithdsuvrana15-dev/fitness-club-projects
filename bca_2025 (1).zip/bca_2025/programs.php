<?php $title = 'Programs'; ?>

<?php include 'header.php'; ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>

<section class="mt-5">
    <div class="container marketing">
        <div class="row featurette align-items-center text-white">
            <div class="col-md-7">
                <h2 class="featurette-heading">Personal Training. <span class="text-muted">Get Trained with a personal assist.</span></h2>
                <p class="lead">Our personal training program offers customized, one-on-one coaching designed to help you achieve your unique health and fitness goals. Whether you're aiming to lose weight, build strength, improve mobility, or enhance athletic performance, our certified trainers create tailored workout plans that fit your lifestyle and needs. With focused attention, expert guidance, and ongoing motivation, you'll progress safely and efficiently—maximizing results every step of the way.One-on-one sessions with certified personal trainers to achieve your fitness goals'.</p>
            </div>
            <div class="col-md-5">
                <img src="<?php echo $base_url; ?>assets/web/images/personal_training.jpg"  height="400" width="500" />

            </div>
        </div>

        <hr class="featurette-divider">

        <div class="row featurette  align-items-center text-white">
            <div class="col-md-7 order-md-2">
                <h2 class="featurette-heading">Group Classes.<span class="text-muted">Get Trained .</span></h2>
                <p class="lead">Our group classes are designed to create a motivating, supportive environment where participants can learn, grow, and achieve their goals together. Led by skilled instructors, each session combines expert guidance with the energy of a community setting, making learning both effective and enjoyable. Whether it’s fitness, wellness, or skill development, our classes cater to all levels and encourage collaboration, accountability, and lasting results.Join our group classes including yoga, pilates, and high-intensity interval training (HIIT).</p>
            </div>
            <div class="col-md-5 order-md-1">
            <img src="<?php echo $base_url; ?>assets/web/images/group_classes.jpg"  height="400" width="500" /> 

            </div>
        </div>

        <hr class="featurette-divider">

        <div class="row featurette  align-items-center text-white">
            <div class="col-md-7">
                <h2 class="featurette-heading">Nutrition Classes. <span class="text-muted">Get nutrition .</span></h2>
                <p class="lead">Our nutrition classes offer practical, science-based guidance to help individuals make informed food choices and develop healthier eating habits. Led by certified nutrition experts, these sessions cover essential topics such as balanced diets, meal planning, label reading, portion control, and the role of nutrition in overall wellness. Whether you're looking to manage weight, improve energy levels, or simply eat smarter, these interactive classes provide the knowledge and tools to support sustainable lifestyle changes.Work with a nutrition expert to build a personalized diet plan for your fitness journey.</p>
            </div>
            <div class="col-md-5">
            <img src="<?php echo $base_url; ?>assets/web/images/nutrition_image.jpg"  height="400" width="500" /> 

            </div>
        </div>
        <hr class="featurette-divider">

<div class="row featurette  align-items-center text-white">
    <div class="col-md-7 order-md-2">
        <h2 class="featurette-heading">Weight Training. <span class="text-muted">Build yourself.</span></h2>
        <p class="lead">Our weight classes are designed to help you build strength, increase muscle tone, and improve overall fitness in a safe and structured group setting. Led by certified trainers, each session combines resistance training techniques using free weights, machines, and bodyweight exercises. These classes are suitable for all fitness levels, offering modifications and progressions to ensure everyone is challenged and supported. Join us to boost your metabolism, enhance your endurance, and feel stronger with every workout.Transform your body with our effective weight training programs, designed for all fitness levels.</p>
    </div>
    <div class="col-md-5">
    <img src="<?php echo $base_url; ?>assets/web/images/weight_training.jpg"  height="500" width="500" /> 

    </div>
</div>


        <hr class="mt-5">

    </div>
</section>

<?php include 'footer.php'; ?>