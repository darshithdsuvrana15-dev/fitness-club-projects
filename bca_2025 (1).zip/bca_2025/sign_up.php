<?php $title = 'Sign Up'; ?>
<?php include 'header.php'; ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>
<?php
include 'connection.php';
$plans = [];

$result = $conn->query("SELECT id, title, price FROM subscription_plan WHERE status = 'active' ORDER BY price ASC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}
?>

<section class="bg-light py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <h1 class="mb-3">Create Account Now!</h1>
                <form id="signup-form">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Phone Number</label>
                            <input type="number" class="form-control" name="phone_number">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Date Of Birth</label>
                            <input type="date" class="form-control" name="dob" id="dob">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">E-Mail</label>
                            <input type="email" class="form-control" name="email">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Plan</label>
                            <select name="plan" class="form-control">
                                <option value="">Select Plan</option>
                                <?php foreach ($plans as $plan): ?>
                                <option value="<?= $plan['id']; ?>"
                                    data-title="<?= htmlspecialchars($plan['title']); ?>"
                                    data-amount="<?= $plan['price']; ?>">
                                    <?= htmlspecialchars($plan['title']) . ' - ₹' . $plan['price']; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mt-5">
                            <button type="button" class="btn btn-dark w-100 fw-bold" id="pay-button">Pay &
                                Signup</button>
                        </div>
                    </div>
                </form>

                <form id="payment-data-form" action="create_user.php" method="POST" style="display:none;">
                    <input type="hidden" name="name">
                    <input type="hidden" name="phone_number">
                    <input type="hidden" name="dob">
                    <input type="hidden" name="email">
                    <input type="hidden" name="plan">
                    <input type="hidden" name="amount">
                    <input type="hidden" name="payment_id" id="payment_id">
                </form>
            </div>
        </div>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    $(document).ready(function() {
        const urlParams = new URLSearchParams(window.location.search);
        const selectedPlan = urlParams.get('plan');
        if (selectedPlan) {
            $('select[name="plan"]').val(selectedPlan);
        }
        flatpickr("#dob", {
            dateFormat: "d-m-Y",
            maxDate: new Date().fp_incr(-16 * 365.25) // edit -16 for change age condition
        });
        $('#pay-button').click(function() {
            const formData = $('#signup-form').serializeArray();
            const formObj = {};
            formData.forEach(field => formObj[field.name] = field.value);
            const fieldLabels = {
                name: 'Name',
                phone_number: 'Phone Number',
                dob: 'Date of Birth',
                email: 'E-Mail',
                plan: 'Plan'
            };
            for (const field in fieldLabels) {
                if (!formObj[field]) {
                    Swal.fire({
                        icon: 'warning',
                        title: `Missing ${fieldLabels[field]}`,
                        text: `Please enter your ${fieldLabels[field]}.`,
                    });
                    return;
                }
            }

            // Phone number validation
            const phonePattern = /^\d{10}$/;
            if (!phonePattern.test(formObj.phone_number)) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Phone Number',
                    text: 'Phone number must be exactly 10 digits.',
                });
                return;
            }

            $.ajax({
                url: 'check_user.php',
                method: 'POST',
                data: formObj,
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'exists') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Email Already Registered',
                            text: 'Please login or use a different email.',
                        });
                    } else if (response.status === 'ok' && !isNaN(response.amount)) {
                        startPayment(formObj, response.amount * 100); // Convert to paisa
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Invalid Plan',
                            text: 'Plan information is not available.',
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Server Error',
                        text: 'Please try again.',
                    });
                }
            });
        });

        function startPayment(formObj, amount) {
            const planTitle = $('select[name="plan"] option:selected').data('title') || 'Plan';
            var options = {
                key: "rzp_test_tzjjBShSxC3SJC",
                amount: amount,
                currency: "INR",
                name: "FITNESS CLUB",
                image: "https://kumaraswamyvidyalaya.com/images/fitness-club-logo.png",
                description: planTitle,
                handler: function(response) {
                    $('#payment-data-form input[name="name"]').val(formObj.name);
                    $('#payment-data-form input[name="phone_number"]').val(formObj.phone_number);
                    $('#payment-data-form input[name="dob"]').val(formObj.dob);
                    $('#payment-data-form input[name="email"]').val(formObj.email);
                    $('#payment-data-form input[name="plan"]').val(formObj.plan);
                    $('#payment-data-form input[name="amount"]').val(amount / 100);
                    $('#payment_id').val(response.razorpay_payment_id);
                    $('#payment-data-form').submit();
                },
                prefill: {
                    name: formObj.name,
                    email: formObj.email
                },
                theme: {
                    color: "#3399cc"
                }
            };
            const rzp = new Razorpay(options);
            rzp.open();
        }
    });
</script>

<?php include 'footer.php'; ?>