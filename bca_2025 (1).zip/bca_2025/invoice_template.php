<h2 style="text-align:center; color: red; font-weight: bold;">FITNESS CLUB</h2>
<p style="text-align:center; font-style: italic;">The New Venue for Fitness</p>
<hr>

<p><strong>Receipt No.:</strong> <?php echo $invoice_number; ?></p>
<p><strong>Payment Id.:</strong> <?php echo $payment_id; ?></p>
<p><strong>Date:</strong> <?php echo $invoice_date; ?></p>
<p><strong>Mrs./Miss./Mr.:</strong> <?php echo $name; ?></p>
<p><strong>Member No.:</strong> <?php echo $member_no; ?></p>
<p><strong>Address:</strong> <?php echo $address; ?></p>

<hr>

<table border="1" width="100%" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>Sr. No.</th>
            <th>Work out Type</th>
            <th>Date of Transaction</th>
            <th>Amount</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td><?php echo $workout_type; ?></td>
            <td>From <?php echo $start_date; ?> to <?php echo $end_date; ?></td>
            <td> Rs. <?php echo number_format($amount, 2); ?></td>
        </tr>
        <tr>
            <td></td>
            <td>Service Tax Charged</td>
            <td colspan="2"><?php echo number_format($tax, 2) . '%'; ?></td>
        </tr>
        <tr>
            <td colspan="3" align="right"><strong>Total</strong></td>
            <td><strong>Rs. <?php echo number_format($total_amount, 2); ?></strong></td>
        </tr>
    </tbody>
</table>

<p><strong>Received Rupees:</strong> <?php echo strtoupper($amount_words); ?></p>
<p><strong>By:</strong> <?php echo $payment_mode; ?></p>

<br><br>
<table width="100%">
    <tr>
        <td><strong>Received by:</strong> <?php echo $received_by; ?></td>
        <td align="right">____________________<br><small>Receiver's Signature</small></td>
    </tr>
</table>
