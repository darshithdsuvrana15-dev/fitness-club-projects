<?php
    include 'connection.php';
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Contact_Form_Report.xls");

    $today = date('Y-m-d');
    $month_start = date('Y-m-01');

    $status_filter = isset($_GET['status']) ? $_GET['status'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $from = isset($_GET['from']) && $_GET['from'] !== '' ? date('Y-m-d', strtotime($_GET['from'])) : $month_start;
    $to = isset($_GET['to']) && $_GET['to'] !== '' ? date('Y-m-d', strtotime($_GET['to'])) : $today;

    $date_range = ($from && $to) ? "From $from To $to" : 'All Dates';
    $search_text = $search ? "$search" : '';

    $sql = "SELECT * FROM contact_form";
    $conditions = [];

    if ($search) {
        $conditions[] = "first_name LIKE '%$search%'";
    }
    if ($from && $to) {
        $conditions[] = "DATE(created_at) BETWEEN '$from' AND '$to'";
    }
    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }

    $result = $conn->query($sql);

    echo "<table border='1'>";
    echo "<tr><th colspan='6' style='text-align:center;font-size:18px;'>Contact Form Report</th></tr>";
    echo "<tr><td colspan='6'><strong>Date Range:</strong> {$date_range}</td></tr>";
    if ($search_text) echo "<tr><td colspan='6'><strong>Search: </strong>{$search_text}</td></tr>";

    echo "<tr><th>#</th><th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Registered At</th></tr>";

    $i = 1;
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $full_name = $row['first_name'] . ' ' . $row['last_name'];
            $date = date('d M Y', strtotime($row['created_at']));
            echo "<tr>
                <td>{$i}</td>
                <td>{$full_name}</td>
                <td>{$row['email']}</td>
                <td>{$row['subject']}</td>
                <td>{$row['message']}</td>
                <td>{$date}</td>
            </tr>";
            $i++;
        }
    } else {
        echo "<tr><td colspan='6'>No records found</td></tr>";
    }

    echo "</table>";
?>
