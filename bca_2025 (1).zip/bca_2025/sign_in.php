<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard");
    exit;
}
?>

<?php $title = 'Sign In'; ?>
<?php include 'header.php';  ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>

<section class="bg-light py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                <h1 class="mb-3">Sign In to dashboard</h1>
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php
                            echo $_SESSION['error'];
                            unset($_SESSION['error']);
                        ?>
                    </div>
                <?php endif; ?>
                <form method="POST" action="login.php">
                    <div class="row g-3">
                        <div class="col-12">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="col-12">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <a class="text-body" href="<?php echo $base_url; ?>forgot_password">Forgot Password</a>
                        </div>
                        <div class="col-12">
                            <div class="row">
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-dark w-100 fw-bold" name="login">Login</button>
                                </div>
                                <div class="col-md-6">
                                    <a href="sign_up.php" class="btn btn-dark w-100 fw-bold">Sign Up</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
