<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php 

if (!isset($_GET['id'])) {
    echo "User ID missing.";
    exit;
}

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $status = $_POST['status'];
    $role = $_POST['role'];

    $update_sql = "UPDATE users SET name = ?, role = ?, status = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sssi", $name, $role, $status, $id);

    if ($update_stmt->execute()) {
        $_SESSION['success'] = "User Updated.";
        
    } else {
        $_SESSION['error'] = "User Update Failed.";
    }
}



// Fetch existing data
$sql = "SELECT u.id AS u_id, u.name, u.role, u.phone_number,u.dob,u.email,u.profile_image,u.status FROM users u WHERE u.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows != 1) {
    echo "User not found.";
    exit;
}

$user = $result->fetch_assoc();

$role_mapping = [
    1 => 'Admin',
    2 => 'Reception',
    3 => 'Trainer',
    4 => 'Customer'
];

$user['role'] = isset($role_mapping[$user['role']]) ? $role_mapping[$user['role']] : 'Unknown Role';

?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
    <h4>Edit User</h4>
    <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php
                            echo $_SESSION['error'];
                            unset($_SESSION['error']);
                        ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success">
                        <?php
                            echo $_SESSION['success'];
                            unset($_SESSION['success']);
                        ?>
                    </div>
                <?php endif; ?>
    <form method="post">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="name"><strong>Name</strong></label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="phone_number"><strong>Phone Number</strong></label>
                    <input type="text" class="form-control" id="phone_number" value="<?php echo htmlspecialchars($user['phone_number']); ?>" disabled>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="email"><strong>E-Mail</strong></label>
                    <input type="text" class="form-control" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label><strong>Role</strong></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="adminRole" value="1" <?php if ($user['role'] == 'Admin') echo 'checked'; ?>>
                        <label class="form-check-label" for="adminRole">Admin</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="receptionRole" value="2" <?php if ($user['role'] == 'Reception') echo 'checked'; ?>>
                        <label class="form-check-label" for="receptionRole">Reception</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="trainerRole" value="3" <?php if ($user['role'] == 'Trainer') echo 'checked'; ?>>
                        <label class="form-check-label" for="trainerRole">Trainer</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="customerRole" value="4" <?php if ($user['role'] == 'Customer') echo 'checked'; ?>>
                        <label class="form-check-label" for="customerRole">Customer</label>
                    </div>
                </div>
            </div>
            
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label><strong>Status</strong></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="active" value="active" <?php if ($user['status'] == 'active') echo 'checked'; ?>>
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="inactive" value="inactive" <?php if ($user['status'] == 'inactive') echo 'checked'; ?>>
                        <label class="form-check-label" for="inactive">Inactive</label>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="profile_image"><strong>Profile Image</strong></label><br>
                    <?php if (!empty($user['profile_image'])): ?>
                        <img src="assets/images/<?php echo $user['profile_image']; ?>" alt="Profile Image" class="img-thumbnail" style="max-width: 150px;">
                    <?php else: ?>
                        <p>No image uploaded.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-primary">Update user</button>
            <a href="users.php" class="btn btn-secondary">Cancel</a>
        </div>
</form>

    </main>
</div>

<?php include 'portal/footer.php'; ?>
