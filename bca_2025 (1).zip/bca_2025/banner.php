<section class="bg-image-full" style="background-image: url('<?php echo $base_url; ?>assets/web/images/bg-image.jpeg')">
    <div class="px-4 py-5 text-center" style="background-color: #03657ea8; padding-top: 10rem !important;">
        <h1 class="display-5 fw-bold text-white"><?php echo $title; ?></h1>
    </div>
</section>