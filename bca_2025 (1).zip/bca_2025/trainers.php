<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php
    $today = date('Y-m-d');
    $month_start = date('Y-m-01');
    
    $status_filter = isset($_GET['status']) ? $_GET['status'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $from = isset($_GET['from']) && $_GET['from'] !== '' ? date('Y-m-d', strtotime($_GET['from'])) : $month_start;
    $to = isset($_GET['to']) && $_GET['to'] !== '' ? date('Y-m-d', strtotime($_GET['to'])) : $today;

    $conditions = [];
    if ($status_filter) {
        $conditions[] = "t.status = '$status_filter'";
    }

    if ($search) {
        $conditions[] = "(u.name LIKE '%$search%' OR u.phone_number LIKE '%$search%')";
    }

    if ($from && $to) {
        $conditions[] = "DATE(t.created_at) BETWEEN '$from' AND '$to'";
    }
    
    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql = " WHERE " . implode(" AND ", $conditions);
    }

    $sql = "SELECT t.id AS t_id, t.user_id, t.trainer_id, t.description, t.created_at AS t_created_at, t.status, u.name, u.phone_number FROM trainers t JOIN users u ON t.user_id = u.id $whereSql";

    $sql .= " ORDER BY t.created_at DESC";

    $result = $conn->query($sql);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['id']) && isset($_POST['status'])) {
            $id = $_POST['id'];
            $status = $_POST['status'];
    
            $update_sql = "UPDATE trainers SET status = ? WHERE user_id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("si", $status, $id);
            $stmt->execute();
    
            if ($stmt->affected_rows > 0) {
                echo "Status updated successfully!";
            } else {
                echo "Failed to update status.";
            }
            $stmt->close();
        }
    }
?>



<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h3 class="d-none d-print-block text-center mb-4">User Report</h3>

        <form method="GET" class="mb-3">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label">Search</label>
                    <input type="text" name="search" class="form-control" placeholder="Search name" value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control">
                        <option value="">All</option>
                        <option value="active" <?= $status_filter == 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $status_filter == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Date From</label>
                    <input type="date" id="from" name="from" class="form-control" value="<?= $from ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Date To</label>
                    <input type="date" id="to" name="to" class="form-control" value="<?= $to ?>">
                </div>
                <div class="col-md-2" style="margin-top: 2rem;">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </div>
            <div class="d-flex justify-content-between">
                <a href="export_trainers.php?<?= http_build_query($_GET) ?>" target="_blank" class="btn btn-success">Export to Excel</a>
            </div>
        </form>

        <table class="table table-bordered" id="userTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Trainer ID</th>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th style="width: 42%;">Description</th>
                    <th>Registered At</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php $i = 1; while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $i++; ?></td>
                            <td><?php echo $row['trainer_id']; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['phone_number']; ?></td>
                            <td><?php echo $row['description']; ?></td>
                            <td><?php echo date('d M Y', strtotime($row['t_created_at'])); ?></td>
                            <td>
                                <span class="badge badge-<?php echo $row['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                    <?php echo ucfirst($row['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="edit_trainer.php?id=<?php echo $row['user_id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                <?php if ($row['status'] == 'active'): ?>
                                    <button class="btn btn-sm btn-warning change-status" data-id="<?php echo $row['user_id']; ?>" data-status="inactive">Deactivate</button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-success change-status" data-id="<?php echo $row['user_id']; ?>" data-status="active">Activate</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center">No trainers found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>
</div>
<?php include 'portal/footer.php'; ?>
<script>
    document.querySelectorAll('.change-status').forEach(button => {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const status = this.getAttribute('data-status');

            Swal.fire({
                title: `Are you sure you want to ${status} this user?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, change it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(window.location.href, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `id=${id}&status=${status}`
                    })
                    .then(response => response.text())
                    .then(data => {
                        Swal.fire('Updated!', 'Status has been changed.', 'success')
                            .then(() => window.location.reload());
                    })
                    .catch(error => {
                        Swal.fire('Error!', 'Something went wrong.', 'error');
                    });
                }
            });
        });
    });
    flatpickr("#from,#to", {
        dateFormat: "Y-m-d",
    });
</script>
