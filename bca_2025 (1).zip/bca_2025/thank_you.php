<?php
include 'connection.php'; // 🔌 Include DB connection

// Check if required parameters are set
if (!isset($_GET['user_id'])) {
    echo "Invalid access.";
    exit;
}

$user_id = (int) $_GET['user_id'];

// Fetch user details
$stmt_user = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();

if ($result_user->num_rows === 0) {
    echo "User not found.";
    exit;
}
$user = $result_user->fetch_assoc();
$name = htmlspecialchars($user['name']);
$email = htmlspecialchars($user['email']);
$stmt_user->close();

// Fetch payment details
$stmt_payment = $conn->prepare("SELECT amount, payment_status, payment_id, paid_on FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt_payment->bind_param("i", $user_id);
$stmt_payment->execute();
$result_payment = $stmt_payment->get_result();

if ($result_payment->num_rows === 0) {
    echo "Payment not found.";
    exit;
}
$payment = $result_payment->fetch_assoc();
$amount = htmlspecialchars($payment['amount']);
$payment_id = htmlspecialchars($payment['payment_id']);
$stmt_payment->close();
$conn->close();
?>

<?php $title = 'Thank You'; ?>
<?php include 'header.php'; ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>

<section class="bg-light py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <p class="text-success" id="timer"></p>
                <h1 class="mb-3">Thank You</h1>
                <p>Your payment of ₹<?= $amount ?> was successful.</p>
                <p>Payment ID: <?= $payment_id ?></p>
                <h2 class="mb-3">Account Created Successfully!</h2>
                <p>Please check your email (<b><?= $email ?></b>) for your <b>username</b> and <b>password</b>.</p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

<script>
    // Set the time for the countdown (1 minutes)
    var countdownTime = 10; // in seconds

    function updateTimer() {
        var minutes = Math.floor(countdownTime / 60);
        var seconds = countdownTime % 60;

        // Display the countdown
        document.getElementById("timer").innerHTML = "Redirecting in: <b>" + minutes + "m " + seconds + "s</b>";

        // Decrease the time by 1 second
        countdownTime--;

        // Redirect when the countdown reaches zero
        if (countdownTime < 0) {
            window.location.href = "sign_in";
        }
    }

    // Update the timer every second
    setInterval(updateTimer, 1000);
</script>


