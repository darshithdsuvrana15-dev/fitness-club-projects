<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    // You can also handle image upload here if needed (e.g., $_FILES['profile_image'])

    // Insert query
    $insert_sql = "INSERT INTO subscription_plan (title, price, duration, description, status) VALUES (?, ?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("sssss", $title, $price, $duration, $description, $status);

    if ($insert_stmt->execute()) {
        $_SESSION['success'] = "Plan added successfully.";
    } else {
        $_SESSION['error'] = "Failed to add plan.";
    }
}
?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h4>Add New Plan</h4>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="title"><strong>Title</strong></label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="price"><strong>Price</strong></label>
                        <input type="number" class="form-control" id="price" name="price" required>
                    </div>
                </div>
            </div>
            

            <div class="row">
                
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="duration"><strong>Duration (in days)</strong></label>
                        <input type="number" class="form-control" id="duration" name="duration" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <label><strong>Status</strong></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="active" value="active" checked>
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="inactive" value="inactive">
                        <label class="form-check-label" for="inactive">Inactive</label>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                 <div class="col-md-12">
                    <div class="form-group">
                        <label><strong>Description</strong></label>
                        <!-- Create Editor Container -->
                        <div id="editor-container" style="height: 150px;"></div>

                        <!-- Hidden input to store content -->
                        <input type="hidden" name="description" id="description">
                    </div>
                </div>
            </div>
            

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-success">Add Plan</button>
                <a href="users.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </main>
</div>

<?php include 'portal/footer.php'; ?>

<script>
  // Step 1: Whitelist font sizes
  var Size = Quill.import('attributors/style/size');
  Size.whitelist = ['small', 'normal', 'large', 'huge'];
  Quill.register(Size, true);

  // Step 2: Initialize Quill with font size and your tools
  var quill = new Quill('#editor-container', {
    theme: 'snow',
    modules: {
      toolbar: [
        [{ 'size': ['small', false, 'large', 'huge'] }],  // Font size
        [{ 'align': [] }],                                // Alignment
        ['bold']                                           // Bold
      ]
    }
  });

  // Step 3: Load existing content for edit (if any)
//   var existingContent = <?php // echo json_encode($trainer['description']); ?>;
//   quill.root.innerHTML = existingContent;

  // Step 4: On form submit, copy HTML to hidden input
  document.querySelector("form").onsubmit = function() {
    document.querySelector("#description").value = quill.root.innerHTML;
  };
</script>
