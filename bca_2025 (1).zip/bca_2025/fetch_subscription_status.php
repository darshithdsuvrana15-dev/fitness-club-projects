<?php
session_start();
include 'connection.php'; // or your DB connection file

if (isset($_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);
    $stmt = $conn->prepare("SELECT end_date FROM payments WHERE user_id = ? AND payment_status = 'success' ORDER BY end_date DESC LIMIT 1");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($end_date);
    if ($stmt->fetch()) {
        $today = date('Y-m-d');
        if ($end_date >= $today) {
            // Active subscription
            echo "Subscription is <strong>active</strong> until <strong>" . date('d M Y', strtotime($end_date)) . "</strong>.";
        } else {
            // Expired subscription
            echo "Subscription <strong>expired</strong> on <strong>" . date('d M Y', strtotime($end_date)) . "</strong>.<br>";
            if($_SESSION['role'] == '4'){
                echo '<a href="'.'renew_subscription'.'" class="btn btn-primary mt-4">Renew Now</a>';
            }
        }
    } else {
        // No subscription found
        echo "No subscription record found.";
    }
    $stmt->close();
}
?>
