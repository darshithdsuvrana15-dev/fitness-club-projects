<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $phone_number = $_POST['phone_number'];
    $email = $_POST['email'];
    $profile_image = '';

    $raw_password = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 8);
    $hashed_password = password_hash($raw_password, PASSWORD_DEFAULT);

    // Basic phone number and email format validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Invalid email format.";
    } else {
        // Check if email already exists
        $check_sql = "SELECT id FROM users WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            $_SESSION['error'] = "Email already registered. Please use a different email.";
        } else {
            // Step 1: Insert basic info first (without image)
            $insert_sql = "INSERT INTO users (name, role, phone_number, email, password, status) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("ssssss", $name, $role, $phone_number, $email, $hashed_password, $status);

            if ($stmt->execute()) {
                $user_id = $stmt->insert_id;

                // Step 2: Handle image upload (if any)
                if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                    $original_name = basename($_FILES['profile_image']['name']);
                    $ext = pathinfo($original_name, PATHINFO_EXTENSION);
                    $new_filename = $user_id . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', pathinfo($original_name, PATHINFO_FILENAME)) . '.' . $ext;
                    $target_path = 'assets/images/' . $new_filename;

                    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_path)) {
                        $update_img_sql = "UPDATE users SET profile_image = ? WHERE id = ?";
                        $img_stmt = $conn->prepare($update_img_sql);
                        $img_stmt->bind_param("si", $new_filename, $user_id);
                        $img_stmt->execute();
                    }
                }

                // Step 3: If role is Trainer (3), insert into trainers table
                if ($role == '3') {

                    // Step 1: Insert trainer with user_id and status
                    $insert_trainer_sql = "INSERT INTO trainers (user_id, status) VALUES (?, ?)";
                    $trainer_stmt = $conn->prepare($insert_trainer_sql);
                    $trainer_stmt->bind_param("is", $user_id, $status);
                    $trainer_stmt->execute();

                    // Step 2: Get the inserted trainer ID
                    $trainer_auto_id = $trainer_stmt->insert_id;

                    // Step 3: Format trainer_id like FC-001
                    $trainer_id = 'FC-' . str_pad($trainer_auto_id, 3, '0', STR_PAD_LEFT);

                    // Step 4: Update the same row with trainer_id
                    $update_trainer_sql = "UPDATE trainers SET trainer_id = ? WHERE id = ?";
                    $update_stmt = $conn->prepare($update_trainer_sql);
                    $update_stmt->bind_param("si", $trainer_id, $trainer_auto_id);
                    $update_stmt->execute();
                }

                // ===== Send Welcome Email =====
                ob_start();
                include 'new_account_mail.php';
                $htmlContent = ob_get_clean();

                $emailData1 = [
                    'sender' => ['name' => 'FITNESS CLUB', 'email' => 'thusharshettigar7483@gmail.com'],
                    'to' => [['email' => $email, 'name' => $name]],
                    'subject' => 'Welcome to Our Gym - Your Login Credentials',
                    'htmlContent' => $htmlContent
                ];

                $ch1 = curl_init();
                curl_setopt($ch1, CURLOPT_URL, "https://api.brevo.com/v3/smtp/email");
                curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch1, CURLOPT_POST, true);
                curl_setopt($ch1, CURLOPT_POSTFIELDS, json_encode($emailData1));
                curl_setopt($ch1, CURLOPT_HTTPHEADER, [
                    'accept: application/json',
                    'api-key: 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',
                    'content-type: application/json',
                ]);
                $response1 = curl_exec($ch1);
                $http_code1 = curl_getinfo($ch1, CURLINFO_HTTP_CODE);
                $curl_error1 = curl_error($ch1);
                curl_close($ch1);

                $status1 = ($curl_error1 || $http_code1 >= 400) ? 'failed' : 'sent';
                $responseText1 = $curl_error1 ? $curl_error1 : $response1;
                $type1 = 'WELCOME';

                $logStmt = $conn->prepare("INSERT INTO email_logs (user_email, user_name, type, status, response) VALUES (?, ?, ?, ?, ?)");
                $logStmt->bind_param("sssss", $email, $name, $type1, $status1, $responseText1);
                $logStmt->execute();
                $logStmt->close();

                $_SESSION['success'] = "User added successfully.";
            }
            else {
                $_SESSION['error'] = "Failed to add user.";
            }
        }
    }
}
?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h4>Add New User</h4>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="name"><strong>Name</strong></label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="phone_number"><strong>Phone Number</strong></label>
                        <input type="text" class="form-control" id="phone_number" name="phone_number" pattern="\d{10}" title="Enter 10 digit phone number" required>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="email"><strong>E-Mail</strong></label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>

                <div class="col-md-6">
                    <label><strong>Role</strong></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="adminRole" value="1" required>
                        <label class="form-check-label" for="adminRole">Admin</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="receptionRole" value="2">
                        <label class="form-check-label" for="receptionRole">Reception</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="trainerRole" value="3">
                        <label class="form-check-label" for="trainerRole">Trainer</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="customerRole" value="4">
                        <label class="form-check-label" for="customerRole">Customer</label>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-md-6">
                    <label><strong>Status</strong></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="active" value="active" checked>
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="inactive" value="inactive">
                        <label class="form-check-label" for="inactive">Inactive</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="profile_image" class="form-label"><strong>Profile Image</strong></label>
                        <input type="file" class="form-control" id="profile_image" name="profile_image" accept="image/*">
                    </div>
                </div>
            </div>
            

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-success">Add User</button>
                <a href="users.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </main>
</div>

<?php include 'portal/footer.php'; ?>
