<?php $title = 'Contact Us'; ?>

<?php include 'header.php'; ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>

<?php 
include 'connection.php';
$messageAlert = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO contact_form (first_name, last_name, email, subject, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $first_name, $last_name, $email, $subject, $message);

    if ($stmt->execute()) {
        $messageAlert = '<div class="alert alert-success">Response Submitted Successfully.</div>';
    } else {
        $messageAlert = '<div class="alert alert-danger">Error: ' . $stmt->error . '</div>';
    }

    $stmt->close();
}
?>


<section class="bg-light py-5">
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-9">
        <h1 class="mb-3">Get In Touch / Submit Your Feedback !</h1>
        <?php echo $messageAlert; ?>
        <form method="POST">
            <div class="row g-3">
            <div class="col-md-6">
                <label for="your-name" class="form-label">Your Name</label>
                <input type="text" class="form-control" id="your-name" name="first_name" required>
            </div>
            <div class="col-md-6">
                <label for="your-surname" class="form-label">Your Surname</label>
                <input type="text" class="form-control" id="your-surname" name="last_name" required>
            </div>
            <div class="col-md-6">
                <label for="your-email" class="form-label">Your Email</label>
                <input type="email" class="form-control" id="your-email" name="email" required>
            </div>
            <div class="col-md-6">
                <label for="your-subject" class="form-label">Your Subject</label>
                <input type="text" class="form-control" id="your-subject" name="subject">
            </div>
            <div class="col-12">
                <label for="your-message" class="form-label">Your Message</label>
                <textarea class="form-control" id="your-message" name="message" rows="5" required></textarea>
            </div>
            <div class="col-12">
                <div class="row">
                <div class="col-md-6">
                    <button type="submit" class="btn btn-dark w-100 fw-bold" >Send</button>
                </div>
                </div>
            </div>
            </div>
        </form>
        </div>
    </div>
    </div>
</section>

<?php include 'footer.php'; ?>