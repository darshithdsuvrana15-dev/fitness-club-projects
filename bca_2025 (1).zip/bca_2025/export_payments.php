<?php
    include 'connection.php';
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Payments_Report.xls");

    $mode_filter = isset($_GET['mode']) ? $_GET['mode'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $search_text = $search ? "$search" : '';

    $conditions = [];
    if ($mode_filter !== '') {
        $conditions[] = "mode = '$mode_filter'";
    }
    if ($search) {
        $conditions[] = "payment_id LIKE '%$search%'";
    }
    
    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql = " WHERE " . implode(" AND ", $conditions);
    }

    $sql = "SELECT p.id, p.amount, p.payment_status, p.payment_id, p.paid_on, p.mode, 
        CASE WHEN p.created_by = 0 THEN 'RAZORPAY' ELSE u1.name END AS received_by, 
        u2.name AS payee_name, 
        pl.title 
    FROM payments p 
    LEFT JOIN users u1 ON p.created_by = u1.id 
    LEFT JOIN users u2 ON p.user_id = u2.id
    LEFT JOIN subscription_plan pl ON p.sp_id = pl.id $whereSql";

    $result = $conn->query($sql);

    echo "<table border='1'>";
    echo "<tr><th colspan='9' style='text-align:center;font-size:18px;'>Payments Report</th></tr>";
    if ($search_text) echo "<tr><td colspan='9'><strong>Search: </strong>{$search_text}</td></tr>";

    echo "<tr><th>ID</th><th>Payee Name</th><th>Payment ID</th><th>Amount</th><th>Plan</th><th>Status</th><th>Registered At</th><th>Received By</th><th>Mode</th></tr>";

    $i = 1;
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $date = date('d M Y', strtotime($row['paid_on']));
            $amount = number_format($row['amount'], 2);
            echo "<tr>
                <td>{$i}</td>
                <td>{$row['payee_name']}</td>
                <td>{$row['payment_id']}</td>
                <td>{$amount}</td>
                <td>{$row['title']}</td>
                <td>{$row['payment_status']}</td>
                <td>{$date}</td>
                <td>{$row['received_by']}</td>
                <td>{$row['mode']}</td>
            </tr>";
            $i++;
        }
    } else {
        echo "<tr><td colspan='6'>No records found</td></tr>";
    }

    echo "</table>";
?>
