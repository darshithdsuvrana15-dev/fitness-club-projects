<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo $site_title; ?> - <?php echo $title ?></title>
    <link rel="icon" href="<?php echo $base_url; ?>assets/web/images/logo.png">
    <meta name="keywords" content="<?php echo ""; ?>"/>
    <meta name="description" content="<?php echo ""; ?>"/>
	  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <meta name="robots" content="index"/>
    <meta property="og:image" content="<?php echo ""; ?>"/>
    <meta property="og:title" content="<?php echo ""; ?>"/>
    <meta property="og:description" content="<?php echo ""; ?>"/>
    <meta property="og:image:width" content="1200"/>
    <meta property="og:image:height" content="630"/>

    <title><?php echo $site_title; ?></title>
    <meta charset="UTF-8">
    <meta http-equiv="x-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/web/css/style.css">

     <!--Bootstrap CSS-->
     <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>assets/web/css/bootstrap.min.css">
     <!-- Flatpickr CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">



</head>

<body class="bg-black">