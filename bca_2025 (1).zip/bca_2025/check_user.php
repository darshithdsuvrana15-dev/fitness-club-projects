<?php
include 'connection.php';

$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$plan = isset($_POST['plan']) ? (int)$_POST['plan'] : 0;

if (empty($email) || $plan === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Email or plan missing']);
    exit;
}

// Check if user already exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    echo json_encode(['status' => 'exists']);
    exit;
}
$stmt->close();

// Fetch amount and title from subscription_plan table
$stmt = $conn->prepare("SELECT price, title FROM subscription_plan WHERE id = ? AND status = 'active'");
$stmt->bind_param("i", $plan);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        'status' => 'ok',
        'amount' => $row['price'],     // amount in rupees
        'title'  => $row['title']
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid or inactive plan selected'
    ]);
}

$stmt->close();
$conn->close();
?>
