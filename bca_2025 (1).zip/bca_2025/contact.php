<?php include 'portal/header.php';  ?>
<?php include 'portal/navigation.php';  ?>

<?php
    $today = date('Y-m-d');
    $month_start = date('Y-m-01');

    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $from = isset($_GET['from']) && $_GET['from'] !== '' ? date('Y-m-d', strtotime($_GET['from'])) : $month_start;
    $to = isset($_GET['to']) && $_GET['to'] !== '' ? date('Y-m-d', strtotime($_GET['to'])) : $today;
    
    $conditions = [];
    if ($search) {
        $conditions[] = "first_name LIKE '%$search%'";
    }
    if ($from && $to) {
        $conditions[] = "DATE(created_at) BETWEEN '$from' AND '$to'";
    }

    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql = " WHERE " . implode(" AND ", $conditions);
    }

    $sql = "SELECT id, first_name, last_name, email, subject, message, created_at FROM contact_form $whereSql";

    $result = $conn->query($sql);

?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h4>Contact Forms</h4>
        <form method="GET" class="mb-3">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label">Search</label>
                    <input type="text" name="search" class="form-control" placeholder="Search by name" value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Date From</label>
                    <input type="date" id="from" name="from" class="form-control" value="<?= $from ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Date To</label>
                    <input type="date" id="to" name="to" class="form-control" value="<?= $to ?>">
                </div>
                <div class="col-md-2" style="margin-top: 2rem;">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </div>
            <div class="d-flex justify-content-between">
                <a href="export_contact_form.php?<?= http_build_query($_GET) ?>" target="_blank" class="btn btn-success">Export to Excel</a>
            </div>
        </form>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Registered At</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): $i = 1; while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= $row['first_name'].' '.$row['last_name'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['subject'] ?></td>
                        <td><?= $row['message'] ?></td>
                        <td><?= date('d M Y', strtotime($row['created_at'])) ?></td>
                    </tr>
                <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">No message found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>
</div>

<?php include 'portal/footer.php'; ?>

<script>
    flatpickr("#from,#to", {
        dateFormat: "Y-m-d",
    });
</script>
