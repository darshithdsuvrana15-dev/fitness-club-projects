<?php
    include 'connection.php';
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=Trainer_Report.xls");

    $today = date('Y-m-d');
    $month_start = date('Y-m-01');
    
    $status_filter = isset($_GET['status']) ? $_GET['status'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $from = isset($_GET['from']) && $_GET['from'] !== '' ? date('Y-m-d', strtotime($_GET['from'])) : $month_start;
    $to = isset($_GET['to']) && $_GET['to'] !== '' ? date('Y-m-d', strtotime($_GET['to'])) : $today;

    $status_label = ($status_filter === 'active') ? 'Active' : (($status_filter === 'inactive') ? 'Inactive' : 'All');
    $date_range = ($from && $to) ? "From $from To $to" : 'All Dates';
    $search_text = $search ? "$search" : '';

    $conditions = [];

    if ($status_filter) {
        $conditions[] = "t.status = '$status_filter'";
    }
    if ($search) {
        $conditions[] = "(u.name LIKE '%$search%' OR u.phone_number LIKE '%$search%')";
    }
    if ($from && $to) {
        $conditions[] = "DATE(t.created_at) BETWEEN '$from' AND '$to'";
    }

    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql .= " WHERE " . implode(" AND ", $conditions);
    }

    $sql = "SELECT t.id AS t_id, t.user_id, t.trainer_id, t.description, t.created_at AS t_created_at, t.status, u.name, u.phone_number FROM trainers t JOIN users u ON t.user_id = u.id $whereSql";

    $result = $conn->query($sql);

    echo "<table border='1'>";
    echo "<tr><th colspan='7' style='text-align:center;font-size:18px;'>Trainer Report</th></tr>";
    echo "<tr><td colspan='7'><strong>Status:</strong> {$status_label}</td></tr>";
    echo "<tr><td colspan='7'><strong>Date Range:</strong> {$date_range}</td></tr>";
    if ($search_text) echo "<tr><td colspan='7'><strong>Search: </strong>{$search_text}</td></tr>";

    echo "<tr><th>#</th><th>Trainer ID</th><th>Name</th><th>Phone</th><th>Description</th><th>Status</th><th>Registered At</th></tr>";

    $i = 1;
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $status = ucfirst($row['status']);
            $date = date('d M Y', strtotime($row['t_created_at']));
            echo "<tr>
                <td>{$i}</td>
                <td>{$row['trainer_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['phone_number']}</td>
                <td>{$row['description']}</td>
                <td>{$status}</td>
                <td>{$date}</td>
            </tr>";
            $i++;
        }
    } else {
        echo "<tr><td colspan='7'>No records found</td></tr>";
    }
    echo "</table>";
?>
