<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $payment_mode = 'CASH';
    $payment_status = 'success';
    $timestamp = date('Ymd_His');
    $payment_id = 'cash_' . $timestamp . '_' . $user_id;
    $paid_on = $_POST['paid_on'];
    $created_by = $_SESSION['user_id'] ? $_SESSION['user_id'] : 0;
    $plan = $_POST['plan'];


    $stmt_plan = $conn->prepare("SELECT price, duration FROM subscription_plan WHERE id = ? AND status = 'active'");
    $stmt_plan->bind_param("i", $plan);
    $stmt_plan->execute();
    $stmt_plan->bind_result($plan_price, $plan_duration);
    $stmt_plan->fetch();

    $amount = $plan_price;

    $stmt_plan->close();
    
    $end_date = date('Y-m-d', strtotime("+$plan_duration days", strtotime($paid_on)));

    $insert_sql = "INSERT INTO payments (user_id, amount, mode, payment_status, payment_id, paid_on, created_by, end_date, sp_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("idssssisi", $user_id, $amount, $payment_mode, $payment_status, $payment_id, $paid_on, $created_by, $end_date,$plan);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Payment added successfully.";
    } else {
        $_SESSION['error'] = "Failed to add payment.";
    }
}

// Fetch active users
$users = [];
$result = $conn->query("SELECT id, name FROM users ORDER BY name ASC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
$plans = [];

$result = $conn->query("SELECT id, title, price FROM subscription_plan WHERE status = 'active' ORDER BY price ASC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}
?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h4>Add Cash Payment</h4>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="row">
                <div class="col-md-3">
                    <label><strong>User (Payee)</strong></label>
                    <select name="user_id" class="form-control selectpicker" required data-live-search="true">
                        <option value="">Select User</option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?= $user['id']; ?>"><?= htmlspecialchars($user['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label><strong>Date of Payment</strong></label>
                    <input type="date" id="paid_on" name="paid_on" class="form-control" value="<?= date('Y-m-d'); ?>" required>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Plan</label>
                    <select name="plan" class="form-control selectpicker" data-live-search="true" name="amount">
                        <option value="">Select Plan</option>
                        <?php foreach ($plans as $plan): ?>
                        <option value="<?= $plan['id']; ?>"
                            data-title="<?= htmlspecialchars($plan['title']); ?>"
                            data-amount="<?= $plan['price']; ?>">
                            <?= htmlspecialchars($plan['title']) . ' - ₹' . $plan['price']; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6 mt-2">
                    <label><strong>Subscription Status</strong></label>
                    <div id="subscription_status" class="alert alert-info p-2">Please select a user to check subscription status.</div>
                </div>

            </div>

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-primary">Add Payment</button>
                <a href="payments_list.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </main>
</div>

<?php include 'portal/footer.php'; ?>

<script>
flatpickr("#paid_on", {
    dateFormat: "Y-m-d",
});
$(document).ready(function() {
    $('select[name="user_id"]').on('change', function() {
        var userId = $(this).val();
        if (userId) {
            $.ajax({
                url: 'fetch_subscription_status.php',
                type: 'POST',
                data: { user_id: userId },
                success: function(response) {
                    $('#subscription_status').html(response);
                }
            });
        } else {
            $('#subscription_status').html('Please select a user to check subscription status.');
        }
    });
});
</script>
