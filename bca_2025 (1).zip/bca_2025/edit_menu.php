<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php
if (!isset($_GET['id'])) {
    echo "Menu is missing.";
    exit;
}

$id = $_GET['id'];

// Fetch existing data
$menu_sql = "SELECT * FROM menu WHERE id = ?";
$menu_stmt = $conn->prepare($menu_sql);
$menu_stmt->bind_param("i", $id);
$menu_stmt->execute();
$menu_result = $menu_stmt->get_result();

if ($menu_result->num_rows === 0) {
    $_SESSION['error'] = "Menu not found.";
}

$menu = $menu_result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $plan = $_POST['plan'];
    $status = $_POST['status'];

    // Update query
    $update_sql = "UPDATE menu SET title=?, description=?,sp_id=?, status=? WHERE id=?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssisi", $title, $description, $plan, $status, $id);

    if ($update_stmt->execute()) {
        $_SESSION['success'] = "Menu Updated.";
    } else {
        $_SESSION['error'] = "Menu Update Failed.";
    }
}
$plans = [];

$result = $conn->query("SELECT id, title, price FROM subscription_plan WHERE status = 'active' ORDER BY price ASC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}
?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h4>Edit Menu</h4>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group mb-3">
                        <label for="title"><strong>Title</strong></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?= htmlspecialchars($menu['title']) ?>" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Select Plan</label>
                    <select name="plan" class="form-control">
                        <option value="">Select</option>
                        <?php foreach ($plans as $plan): ?>
                        <option value="<?= $plan['id']; ?>"
                            data-title="<?= htmlspecialchars($plan['title']); ?>"
                            data-amount="<?= $plan['price']; ?>"
                            <?= ($plan['id'] == $menu['sp_id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($plan['title']) . ' - ₹' . $plan['price']; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label><strong>Status</strong></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="active" value="active" <?= $menu['status'] === 'active' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="inactive" value="inactive" <?= $menu['status'] === 'inactive' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="inactive">Inactive</label>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                 <div class="col-md-12">
                    <div class="form-group">
                        <label><strong>Description</strong></label>
                        <div id="editor-container" style="height: 150px;"></div>
                        <input type="hidden" name="description" id="description">
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-primary">Update Plan</button>
                <a href="plans.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </main>
</div>

<?php include 'portal/footer.php'; ?>

<script>
  var Size = Quill.import('attributors/style/size');
  Size.whitelist = ['small', 'normal', 'large', 'huge'];
  Quill.register(Size, true);

  var quill = new Quill('#editor-container', {
    theme: 'snow',
    modules: {
      toolbar: [
        [{ 'size': ['small', false, 'large', 'huge'] }],
        [{ 'align': [] }],
        ['bold']
      ]
    }
  });

  // Set existing content
  var existingContent = <?= json_encode($menu['description']) ?>;
  quill.root.innerHTML = existingContent;

  // On submit, transfer HTML to hidden input
  document.querySelector("form").onsubmit = function() {
    document.querySelector("#description").value = quill.root.innerHTML;
  };
</script>
