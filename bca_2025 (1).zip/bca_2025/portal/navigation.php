<div class="container-fluid">
    <div class="row">
        <!-- sidebar -->
        <div class="col-md-3 col-lg-2 px-0 position-fixed h-100 bg-white shadow-sm sidebar" id="sidebar">
            <div class="text-center">
                <a class="navbar-brand" href="<?php echo $base_url; ?>dashboard">
                    <img src="<?php echo $base_url; ?>assets/web/images/logo.png" style="width: 120px;" />
                </a>
            </div>
            <div class="list-group rounded-0">
                <a href="<?php echo $base_url; ?>dashboard"
                    class="list-group-item list-group-item-action <?= ($activePage == 'dashboard.php') ? 'active' : ''; ?> border-0 d-flex align-items-center">
                    <span class="bi bi-border-style"></span>
                    <span class="ml-2">Dashboard</span>
                </a>
                <?php if($_SESSION['role'] == '1') { ?>
                <a href="<?php echo $base_url; ?>users"
                    class="list-group-item list-group-item-action <?= ($activePage == 'users.php') ? 'active' : ''; ?> border-0 align-items-center">
                    <span class="bi bi-people-fill"></span>
                    <span class="ml-2">Users</span>
                </a>
                <a href="<?php echo $base_url; ?>contact"
                    class="list-group-item list-group-item-action <?= ($activePage == 'contact.php') ? 'active' : ''; ?> border-0 align-items-center">
                    <span class="bi bi-person-lines-fill"></span>
                    <span class="ml-2">Contact Form</span>
                </a>
                <a href="<?php echo $base_url; ?>trainers"
                    class="list-group-item list-group-item-action <?= ($activePage == 'trainers.php') ? 'active' : ''; ?> border-0 align-items-center">
                    <span class="bi bi-bounding-box"></span>
                    <span class="ml-2">Trainers</span>
                </a>
                <a href="<?php echo $base_url; ?>subscription"
                    class="list-group-item list-group-item-action <?= ($activePage == 'subscription.php') ? 'active' : ''; ?> border-0 align-items-center">
                    <span class="bi bi-tag-fill"></span>
                    <span class="ml-2">Subscription</span>
                </a>
                <a href="<?php echo $base_url; ?>menu"
                    class="list-group-item list-group-item-action <?= ($activePage == 'menu.php') ? 'active' : ''; ?> border-0 align-items-center">
                    <span class="bi bi-list"></span>
                    <span class="ml-2">Menu</span>
                </a>
                <?php } ?>  
                <?php if($_SESSION['role'] == '1' || $_SESSION['role'] == '2') { ?>
                <a href="<?php echo $base_url; ?>payments"
                    class="list-group-item list-group-item-action <?= ($activePage == 'payments.php') ? 'active' : ''; ?> border-0 align-items-center">
                    <span class="bi bi-cash"></span>
                    <span class="ml-2">Payments</span>
                </a>
                <?php } ?>  
                <?php if($_SESSION['role'] == '1' || $_SESSION['role'] == '2' || $_SESSION['role'] == '3') { ?>
                <a href="<?php echo $base_url; ?>attendance"
                    class="list-group-item list-group-item-action <?= ($activePage == 'attendance.php') ? 'active' : ''; ?> border-0 align-items-center">
                    <span class="bi bi-calendar-check"></span>
                    <span class="ml-2">Attendance</span>
                </a>
                <?php } ?>  
            </div>
        </div>
        <!-- overlay to close sidebar on small screens -->
        <div class="w-100 vh-100 position-fixed overlay d-none" id="sidebar-overlay"></div>
        <!-- note: in the layout margin auto is the key as sidebar is fixed -->
        <div class="col-md-9 col-lg-10 ml-md-auto px-0">
            <!-- top nav -->
            <nav class="w-100 d-flex px-4 py-2 mb-4 shadow-sm">
                <!-- close sidebar -->
                <button class="btn py-0 d-lg-none" id="open-sidebar">
                    <span class="bi bi-list text-primary h3"></span>
                </button>
                <div class="dropdown ml-auto">
                    <button class="btn py-0 d-flex align-items-center" id="logout-dropdown" data-toggle="dropdown"
                        aria-expanded="false">
                        <span class="bi bi-person text-primary h4"></span>
                        <span class="bi bi-chevron-down ml-1 mb-2 small"></span>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right border-0 shadow-sm"
                        aria-labelledby="logout-dropdown">
                        <a class="dropdown-item"
                            href="edit_profile.php?<?= $_SESSION['user_id'] ?>">Profile</a>
                        <a class="dropdown-item"
                            href="logout.php">Logout</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>