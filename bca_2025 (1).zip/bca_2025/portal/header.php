
<?php include 'config.php'; ?>
<?php 
include 'connection.php';


session_start();

// Set timeout duration in seconds (e.g., 15 minutes = 900 seconds)
$timeout_duration = 3600;

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to access dashboard.";
    header("Location: sign_in");
    exit;
}

// Check for session timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $timeout_duration) {
    // Session expired
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['error'] = "Session expired due to inactivity. Please login again.";
    header("Location: sign_in");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title><?php if($_SESSION['role'] == 1) { echo 'Admin'; } elseif($_SESSION['role'] == 2) { echo 'Customer'; } ?> Dashboard - Fitness Club</title>

    <link rel="icon" href="<?php echo $base_url; ?>assets/web/images/logo.png">

    <link rel="canonical" href="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?php echo $base_url; ?>assets/portal/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>assets/portal/css/bootstrap-icons.css">

     <!-- Flatpickr CSS -->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

     <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

     <link rel="stylesheet" href="<?php echo $base_url; ?>assets/portal/css/style.css">
     <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css'>




    <style>
        @import url('https://fonts.googleapis.com/css2?family=Barlow&display=swap');

        body {
            font-family: 'Barlow', sans-serif;
        }

        a:hover {
            text-decoration: none;
        }

        .border-left {
            border-left: 2px solid var(--primary) !important;
        }


        .sidebar {
            top: 0;
            left: 0;
            z-index: 100;
            overflow-y: auto;
        }

        .overlay {
            background-color: rgb(0 0 0 / 45%);
            z-index: 99;
        }

        /* sidebar for small screens */
        @media screen and (max-width: 767px) {

            .sidebar {
                max-width: 18rem;
                transform: translateX(-100%);
                transition: transform 0.4s ease-out;
            }

            .sidebar.active {
                transform: translateX(0);
            }

        }
    </style>

</head>

<body translate="no">