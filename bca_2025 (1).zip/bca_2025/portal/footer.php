<script src="<?php echo $base_url; ?>assets/portal/js/jquery.min.js"></script>
<script src="<?php echo $base_url; ?>assets/portal/js/popper.min.js"></script>
<script src="<?php echo $base_url; ?>assets/portal/js/bootstrap.min.js"></script>
<!-- Flatpickr JS -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js'></script>

</body>

</html>