<?php include 'portal/header.php';  ?>
<?php include 'portal/navigation.php';  ?>
<?php
    $today = date('Y-m-d');
    $month_start = date('Y-m-01');
    
    $status_filter = isset($_GET['status']) ? $_GET['status'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $from = isset($_GET['from']) && $_GET['from'] !== '' ? date('Y-m-d', strtotime($_GET['from'])) : $month_start;
    $to = isset($_GET['to']) && $_GET['to'] !== '' ? date('Y-m-d', strtotime($_GET['to'])) : $today;
    $role_filter = isset($_GET['role']) ? $_GET['role'] : '';
    
    $roles = [
        '1' => 'Admin',
        '2' => 'Receptionist',
        '3' => 'Trainer',
        '4' => 'Customer'
    ];
    
    $limit = 10;
    $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;
    
    $count_sql = "SELECT COUNT(*) as total FROM users u";
    if (!empty($conditions)) {
        $count_sql .= " WHERE " . implode(" AND ", $conditions);
    }
    $count_result = $conn->query($count_sql);
    $total_rows = $count_result->fetch_assoc()['total'];
    $total_pages = ceil($total_rows / $limit);
    
    $conditions = [];
    if ($status_filter !== '') {
        $conditions[] = "status = '$status_filter'";
    }
    if ($search) {
        $conditions[] = "name LIKE '%$search%'";
    }
    if ($from && $to) {
        $conditions[] = "DATE(created_at) BETWEEN '$from' AND '$to'";
    }
    if ($role_filter !== '') {
        $conditions[] = "role = '$role_filter'";
    }
    
    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql = " WHERE " . implode(" AND ", $conditions);
    }
    
    $count_sql = "SELECT COUNT(*) as total FROM users u $whereSql";
    $count_result = $conn->query($count_sql);
    $total_rows = $count_result->fetch_assoc()['total'];
    $total_pages = ceil($total_rows / $limit);
    
    $sql = "SELECT 
        u.*, 
        (
            SELECT 
                CASE 
                    WHEN p.end_date >= CURDATE() 
                    THEN CONCAT('Active till ', DATE_FORMAT(p.end_date, '%d-%m-%Y')) 
                    ELSE 'Expired' 
                END 
            FROM payments p 
            WHERE 
                p.user_id = u.id 
                AND p.payment_status = 'success' 
                AND p.end_date IS NOT NULL
            ORDER BY p.end_date DESC 
            LIMIT 1
        ) AS subscription_status 
    FROM users u
    $whereSql
    ORDER BY u.created_at DESC 
    LIMIT $limit OFFSET $offset";
    
    $result = $conn->query($sql);
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['id']) && isset($_POST['status'])) {
            $id = $_POST['id'];
            $status = $_POST['status'];
    
            $update_sql = "UPDATE users SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("si", $status, $id);
            $stmt->execute();
    
            if ($stmt->affected_rows > 0) {
                echo "Status updated successfully!";
            } else {
                echo "Failed to update status.";
            }
            $stmt->close();
        }
    }
?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
    <h4>Users</h4>
    <form method="GET" class="mb-3">
        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Search</label>
                <input type="text" name="search" class="form-control" placeholder="Search name" value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All</option>
                    <option value="active" <?= $status_filter == 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= $status_filter == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Role</label>
                <select name="role" class="form-control">
                    <option value="">All</option>
                    <?php foreach ($roles as $key => $label): ?>
                        <option value="<?= $key ?>" <?= $role_filter == $key ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Date From</label>
                <input type="date" id="from" name="from" class="form-control" value="<?= $from ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Date To</label>
                <input type="date" id="to" name="to" class="form-control" value="<?= $to ?>">
            </div>
            <div class="col-md-2" style="margin-top: 2rem;">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
        <div class="d-flex justify-content-between">

            <a href="add_user.php" class="btn btn-secondary">Add New User</a>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Role</th>
                <th>Status</th>
                <th>Subscription Status</th>
                <th>Actions</th>
                <th>Date</th>
            </tr>
        </thead>

        <tbody>
            <?php if ($result->num_rows > 0): $i = 1; while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $i++ ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['phone_number'] ?></td>
                    <td><?php echo isset($roles[$row['role']]) ? $roles[$row['role']] : 'Unknown'; ?></td>
                    <td>
                        <span class="badge badge-<?php echo $row['status'] == 'active' ? 'success' : 'secondary'; ?>">
                            <?php echo ucfirst($row['status']); ?>
                        </span>
                    </td>
                    <td><?= $row['subscription_status'] ? $row['subscription_status'] : 'N/A' ?></td>
                    <td>
                        <a href="edit_user.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                        <?php if ($row['status'] == 'active'): ?>
                            <button class="btn btn-sm btn-warning change-status" data-id="<?= $row['id']; ?>" data-status="inactive">Deactivate</button>
                        <?php else: ?>
                            <button class="btn btn-sm btn-success change-status" data-id="<?= $row['id']; ?>" data-status="active">Activate</button>
                        <?php endif; ?>
                    </td>
                    <td><?= date('d M Y', strtotime($row['created_at'])) ?></td>
                </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center">No users found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="pagination mt-3">
            <nav>
                <ul class="pagination">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">Previous</a>
                        </li>
                    <?php endif; ?>
        
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
        
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </main>
</div>
<?php include 'portal/footer.php'; ?>
<script>
    document.querySelectorAll('.change-status').forEach(button => {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const status = this.getAttribute('data-status');

            Swal.fire({
                title: `Are you sure you want to ${status} this user?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, change it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(window.location.href, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `id=${id}&status=${status}`
                    })
                    .then(response => response.text())
                    .then(data => {
                        Swal.fire('Updated!', 'Status has been changed.', 'success')
                            .then(() => window.location.reload());
                    })
                    .catch(error => {
                        Swal.fire('Error!', 'Something went wrong.', 'error');
                    });
                }
            });
        });
    });
    flatpickr("#from,#to", {
        dateFormat: "Y-m-d",
    });
</script>