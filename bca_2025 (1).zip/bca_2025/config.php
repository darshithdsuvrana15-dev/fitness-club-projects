<?php
    $site_title = 'FITNESS CLUB';
    $base_url = 'http://localhost/bca_2025/';
    $activePage = basename($_SERVER['PHP_SELF'], "");
?>