<?php
    include 'connection.php';
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=User_Report.xls");

    $today = date('Y-m-d');
    $month_start = date('Y-m-01');
    
    $status_filter = isset($_GET['status']) ? $_GET['status'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $from = isset($_GET['from']) && $_GET['from'] !== '' ? date('Y-m-d', strtotime($_GET['from'])) : $month_start;
    $to = isset($_GET['to']) && $_GET['to'] !== '' ? date('Y-m-d', strtotime($_GET['to'])) : $today;
    $role_filter = isset($_GET['role']) ? $_GET['role'] : '';

    $status_label = ($status_filter === 'active') ? 'Active' : (($status_filter === 'inactive') ? 'Inactive' : 'All');
    $date_range = ($from && $to) ? "From $from To $to" : 'All Dates';
    $search_text = $search ? "$search" : '';
    
    $roles = [
        '1' => 'Admin',
        '2' => 'Receptionist',
        '3' => 'Trainer',
        '4' => 'Customer'
    ];

    $conditions = [];
    if ($status_filter !== '') {
        $conditions[] = "status = '$status_filter'";
    }
    if ($search) {
        $conditions[] = "name LIKE '%$search%'";
    }
    if ($from && $to) {
        $conditions[] = "DATE(created_at) BETWEEN '$from' AND '$to'";
    }
    if ($role_filter !== '') {
        $conditions[] = "role = '$role_filter'";
    }

    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql = " WHERE " . implode(" AND ", $conditions);
    }

    $sql = "SELECT 
        u.*, 
        (
            SELECT 
                CASE 
                    WHEN p.end_date >= CURDATE() 
                    THEN CONCAT('Active till ', DATE_FORMAT(p.end_date, '%d-%m-%Y')) 
                    ELSE 'Expired' 
                END 
            FROM payments p 
            WHERE 
                p.user_id = u.id 
                AND p.payment_status = 'success' 
                AND p.end_date IS NOT NULL
            ORDER BY p.end_date DESC 
            LIMIT 1
        ) AS subscription_status 
    FROM users u
    $whereSql
    ORDER BY u.created_at DESC";

    $result = $conn->query($sql);

    echo "<table border='1'>";
    echo "<tr><th colspan='7' style='text-align:center;font-size:18px;'>User Report</th></tr>";
    echo "<tr><td colspan='7'><strong>Status:</strong> {$status_label}</td></tr>";
    echo "<tr><td colspan='7'><strong>Date Range:</strong> {$date_range}</td></tr>";
    if ($search_text) echo "<tr><td colspan='7'><strong>Search: </strong>{$search_text}</td></tr>";

    echo "<tr><th>#</th><th>Name</th><th>Email</th><th>Phone NUmber</th><th>Status</th><th>Role</th><th>Date</th></tr>";
    
    $i = 1;

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $role_name = isset($roles[$row['role']]) ? $roles[$row['role']] : 'Unknown';
            $status_text = ($row['status'] == 'active') ? 'Active' : 'Inactive';
            $date = date('d M Y', strtotime($row['created_at']));
            echo "<tr>
                <td>{$i}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['phone_number']}</td>
                <td>{$status_text}</td>
                <td>{$role_name}</td>
                <td>{$date}</td>
            </tr>";
            $i++;
        }
    } else {
        echo "<tr><td colspan='6'>No records found</td></tr>";
    }

    echo "</table>";
?>
