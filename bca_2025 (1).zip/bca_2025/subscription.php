<?php include 'portal/header.php';  ?>
<?php include 'portal/navigation.php';  ?>
<?php 

    $status_filter = isset($_GET['status']) ? $_GET['status'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';

    $conditions = [];
    if ($status_filter !== '') {
        $conditions[] = "status = '$status_filter'";
    }
    if ($search) {
        $conditions[] = "title LIKE '%$search%'";
    }
    
    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql = " WHERE " . implode(" AND ", $conditions);
    }

    $sql = "SELECT id, title, description, status, price, created_at FROM subscription_plan $whereSql";
    $result = $conn->query($sql);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['id']) && isset($_POST['status'])) {
            $id = $_POST['id'];
            $status = $_POST['status'];

            $update_sql = "UPDATE subscription_plan SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("si", $status, $id);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                echo "Status updated successfully!";
            } else {
                echo "Failed to update status.";
            }
            $stmt->close();
        }
    }    
?>

 <div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
    <form method="GET" class="mb-3">
        <div class="row mb-3">
            <div class="col-md-3">
                <label class="form-label">Search</label>
                <input type="text" name="search" class="form-control" placeholder="Search plan" value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All</option>
                    <option value="active" <?= $status_filter == 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= $status_filter == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
           
            <div class="col-md-3" style="margin-top: 2rem;">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
        <div class="d-flex justify-content-between">
            <a href="add_subscription.php" class="btn btn-secondary">Add New Plan</a>
        </div>
    </form>

<h3 class="d-none d-print-block text-center mb-4">User Report</h3>

    <table class="table table-bordered" id="userTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Registered At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php $i = 1; while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                         <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                        <td>
                        <a href="edit_subscription.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                        <?php if ($row['status'] == 'active'): ?>
                            <button class="btn btn-sm btn-warning change-status" data-id="<?php echo $row['id']; ?>" data-status="inactive">Deactivate</button>
                        <?php else: ?>
                            <button class="btn btn-sm btn-success change-status" data-id="<?php echo $row['id']; ?>" data-status="active">Activate</button>
                        <?php endif; ?>
                    </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">No plans found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </main>
</div>

<script>
document.querySelectorAll('.change-status').forEach(button => {
    button.addEventListener('click', function () {
        const id = this.getAttribute('data-id');
        const status = this.getAttribute('data-status');

        Swal.fire({
            title: `Are you sure you want to ${status} this plan?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, change it!'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(window.location.href, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `id=${id}&status=${status}`
                })
                .then(response => response.text())
                .then(data => {
                    Swal.fire('Updated!', 'Status has been changed.', 'success')
                        .then(() => window.location.reload());
                })
                .catch(error => {
                    Swal.fire('Error!', 'Something went wrong.', 'error');
                });
            }
        });
    });
});
</script>

<?php include 'portal/footer.php';  ?>