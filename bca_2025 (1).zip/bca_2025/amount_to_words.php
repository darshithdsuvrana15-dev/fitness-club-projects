<?php 
function convertNumberToWords($number) {
    $words = array(
        '0'=> '', '1'=> 'One', '2'=> 'Two', '3'=> 'Three', '4'=> 'Four',
        '5'=> 'Five', '6'=> 'Six', '7'=> 'Seven', '8'=> 'Eight', '9'=> 'Nine',
        '10'=> 'Ten', '11'=> 'Eleven', '12'=> 'Twelve', '13'=> 'Thirteen', '14'=> 'Fourteen',
        '15'=> 'Fifteen', '16'=> 'Sixteen', '17'=> 'Seventeen', '18'=> 'Eighteen', '19'=> 'Nineteen',
        '20'=> 'Twenty', '30'=> 'Thirty', '40'=> 'Forty', '50'=> 'Fifty',
        '60'=> 'Sixty', '70'=> 'Seventy', '80'=> 'Eighty', '90'=> 'Ninety'
    );

    $digits = ['', 'Hundred', 'Thousand', 'Lakh', 'Crore'];
    $number = round($number);
    $result = '';

    if ($number == 0) {
        return 'Zero';
    }

    $i = 0;
    $str = [];
    while ($number > 0) {
        $divider = ($i == 2) ? 10 : 100;
        $numberPart = $number % $divider;
        $number = floor($number / $divider);
        $i += ($divider == 10) ? 1 : 2;

        if ($numberPart) {
            $plural = ($numberPart > 9) ? ' ' : '';
            $hundreds = ($i == 2 && $number > 0) ? ' and ' : '';
            if ($numberPart < 21) {
                $str[] = $words[$numberPart] . ' ' . $digits[$i / 2];
            } else {
                $tens = floor($numberPart / 10) * 10;
                $units = $numberPart % 10;
                $str[] = $words[$tens] . ' ' . $words[$units] . ' ' . $digits[$i / 2];
            }
        }
    }

    $result = implode(' ', array_reverse($str));
    return trim($result);
}

?>