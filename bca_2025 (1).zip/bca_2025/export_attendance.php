<?php
include 'connection.php';

// Get the year and month from GET parameters or set defaults
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$month = isset($_GET['month']) ? $_GET['month'] : date('m');

// Fetch members
$members = [];
$res_members = mysqli_query($conn, "SELECT id, name FROM users");
while ($m = mysqli_fetch_assoc($res_members)) {
    $members[$m['id']] = $m['name'];
}

// Generate all dates in selected month
$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$dates = [];
for ($d = 1; $d <= $daysInMonth; $d++) {
    $dates[] = sprintf("%04d-%02d-%02d", $year, $month, $d);
}

// Fetch attendance records for the month
$attendance = [];
$res = mysqli_query($conn, "
    SELECT * FROM gym_attendance 
    WHERE MONTH(attendance_date) = $month AND YEAR(attendance_date) = $year
");

while ($row = mysqli_fetch_assoc($res)) {
    $attendance[$row['attendance_date']][$row['user_id']] = $row['status'];
}

// Set the headers for Excel export
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Attendance_Report_{$year}_{$month}.xls");

// Output the table with Month and Year Heading
echo "<table border='1'>";
echo "<tr><th colspan='" . (count($dates) + 1) . "'>Attendance Report for " . date('F', mktime(0, 0, 0, $month, 10)) . " {$year}</th></tr>";
echo "<tr><th>User Name</th>";

// Add the date columns
foreach ($dates as $date) {
    echo "<th>" . date('d', strtotime($date)) . "</th>";  // Display day only
}
echo "</tr>";

// Add attendance data for each member
foreach ($members as $member_id => $name) {
    echo "<tr>";
    echo "<td>$name</td>";
    foreach ($dates as $date) {
        // Check if there's attendance data for the specific user and date
        echo "<td>" . (isset($attendance[$date][$member_id]) ? $attendance[$date][$member_id] : '-') . "</td>";
    }
    echo "</tr>";
}
echo "</table>";
?>
