<?php include 'portal/header.php'; ?>

<?php
// Update last activity time
$_SESSION['last_activity'] = time();

// Total users
$total_users_result = $conn->query("SELECT COUNT(*) AS total FROM users");

$total_users = $total_users_result->fetch_assoc()['total'];

// Active users
$active_users_result = $conn->query("SELECT COUNT(*) AS active FROM users WHERE status = 'active'");

$active_users = $active_users_result->fetch_assoc()['active'];

// Inactive users
$inactive_users_result = $conn->query("SELECT COUNT(*) AS inactive FROM users WHERE status = 'inactive'");

$inactive_users = $inactive_users_result->fetch_assoc()['inactive'];

// Contact Form Responses
$contact_form_responses = $conn->query("SELECT COUNT(*) AS contact_responses FROM contact_form");

$contact_responses = $contact_form_responses->fetch_assoc()['contact_responses'];

// Total trainers
$total_trainers_result = $conn->query("SELECT COUNT(*) AS total FROM trainers");

$total_trainers = $total_trainers_result->fetch_assoc()['total'];

// Active trainers
$active_trainers_result = $conn->query("SELECT COUNT(*) AS active FROM users u LEFT JOIN trainers t ON u.id = t.user_id WHERE t.status = 'active' AND u.role = '3'");

$active_trainers = $active_trainers_result->fetch_assoc()['active'];

// Inactive trainers
$inactive_trainers_result = $conn->query("SELECT COUNT(*) AS inactive FROM users u LEFT JOIN trainers t ON u.id = t.user_id WHERE t.status = 'inactive' AND u.role = '3'");

$inactive_trainers = $inactive_trainers_result->fetch_assoc()['inactive'];

// Total Amount
$total_amount_result = $conn->query("SELECT SUM(amount) AS amount FROM payments");

$total_amount = $total_amount_result->fetch_assoc()['amount'];


// Fetch dynamic membership plan distribution data from the database with plan names
$plan_distribution_result = $conn->query("
    SELECT 
        payments.sp_id, 
        COUNT(*) AS plan_count, 
        subscription_plan.title AS plan_name 
    FROM 
        payments 
    JOIN 
        subscription_plan ON payments.sp_id = subscription_plan.id 
    WHERE 
        payments.end_date >= CURDATE() 
    GROUP BY 
        payments.sp_id
");


$plans = [];
$plan_distribution = [];
$plan_names = [];
while ($row = $plan_distribution_result->fetch_assoc()) {
    $plan_names[] = $row['plan_name'];
    $plans[] = $row['sp_id'];
    $plan_distribution[] = $row['plan_count'];
}

// Fetch total number of payments
$total_payments_result = $conn->query("SELECT COUNT(*) AS total_payments FROM payments");

$total_payments = $total_payments_result->fetch_assoc()['total_payments'];

// Fetch payment method distribution (cash vs online) with total amounts
$payment_distribution_result = $conn->query("SELECT mode, SUM(amount) AS total_amount FROM payments GROUP BY mode");

$mode = [];
$payment_distribution = [];
while ($row = $payment_distribution_result->fetch_assoc()) {
    $mode[] = $row['mode'];
    $payment_distribution[] = $row['total_amount']; // Use total amount for the distribution
}
// Fetch user signups by month (dynamically)
$signup_distribution_result = $conn->query("SELECT MONTH(created_at) AS month, COUNT(*) AS signup_count FROM users GROUP BY MONTH(created_at)");

$signup_months = [];
$user_signups = [];
while ($row = $signup_distribution_result->fetch_assoc()) {
    $signup_months[] = date('F', mktime(0, 0, 0, $row['month'], 10));
    $user_signups[] = $row['signup_count'];
}



$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : '';

if(isset($_GET['user_id'])){
    // Fetch user details
    $stmt_user = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();

    if ($result_user->num_rows === 0) {
        echo "User not found.";
        exit;
    }
    $user = $result_user->fetch_assoc();
    $name = htmlspecialchars($user['name']);
    $email = htmlspecialchars($user['email']);
    $stmt_user->close();

    // Fetch payment details
    $stmt_payment = $conn->prepare("SELECT amount, payment_status, payment_id, paid_on FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 1");
    $stmt_payment->bind_param("i", $user_id);
    $stmt_payment->execute();
    $result_payment = $stmt_payment->get_result();

    if ($result_payment->num_rows === 0) {
        echo "Payment not found.";
        exit;
    }
    $payment = $result_payment->fetch_assoc();
    $amount = htmlspecialchars($payment['amount']);
    $payment_id = htmlspecialchars($payment['payment_id']);
    $stmt_payment->close();

}

// Get the trainer for this user
$stmt_trainer = $conn->prepare("
    SELECT u.id AS trainer_id, u.name AS trainer_name, u.email AS trainer_email
    FROM trainer_customers tc
    JOIN users u ON tc.trainer_id = u.id
    WHERE tc.customer_id = ?
    LIMIT 1
");

$stmt_trainer->bind_param("i", $_SESSION['user_id']);
$stmt_trainer->execute();
$result_trainer = $stmt_trainer->get_result();

 $trainer_info = NULL;

 if (!$stmt_trainer->execute()) {
    echo "Execute error: " . $stmt_trainer->error;
}


if ($result_trainer->num_rows > 0) {
    $trainer_info = $result_trainer->fetch_assoc();
}

$stmt_trainer->close();

$stmt = $conn->prepare("
    SELECT 
        sp.id AS plan_id,
        sp.title,
        sp.price,
        m.id AS menu_id,
        m.title AS menu_name,
        m.description AS menu_description
    FROM payments p
    JOIN subscription_plan sp ON p.sp_id = sp.id
    JOIN menu m ON m.sp_id = sp.id
    WHERE p.user_id = ?
    ORDER BY p.id DESC LIMIT 1
");

$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

$menu_items = [];
$plan_info = [];

while ($row = $result->fetch_assoc()) {
    $plan_info = [
        'plan_id' => $row['plan_id'],
        'title' => $row['title'],
        'price' => $row['price']
    ];
    
    $menu_items[] = [
        'menu_id' => $row['menu_id'],
        'name' => $row['menu_name'],
        'description' => $row['menu_description']
    ];
}

$stmt->close();

$stmt = $conn->prepare("
    SELECT u.id, u.name, u.phone_number, u.email
    FROM trainer_customers tc
    JOIN users u ON tc.customer_id = u.id
    WHERE tc.trainer_id = ?
");

$stmt->bind_param("i", $_SESSION['user_id']); 
$stmt->execute();
$customers_result = $stmt->get_result();

?>

<?php include 'portal/navigation.php'; ?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <!-- main content -->
    <main class="container-fluid">
        <div class="rounded bg-white border-0 shadow-sm border-left p-4 mb-4">
            <div class="container">
                <h1 class="display-4 mb-2 text-primary">Welcome</h1>
                <p class="lead text-muted"><?php echo $_SESSION['user_name']; ?></p>
                <?php if($_SESSION['role'] == '4') { ?>
                <span id="subscription_status"></span>
                <?php } ?>
            </div>
        </div>
    </main>
    
    <?php if(isset($_GET['user_id'])){ ?>
        <main class="container-fluid">
            <section class="bg-light p-5 mb-5">
                <p class="text-success" id="timer"></p>
                <h1 class="mb-3">Thank You</h1>
                <p>Your payment of ₹<?= $amount ?> was successful.</p>
                <p>Payment ID: <?= $payment_id ?></p>
                <h2 class="mb-3">Account Renewed  Successfully!</h2>
                <p>Please check your email (<b><?= $email ?></b>) for <b>invoice</b>.</p>
            </section>
        </main>
    <?php } ?>

    <?php if($_SESSION['role'] == '4') { ?>
        <main class="container-fluid">
            <section class="bg-light p-5">
                <?php if ($trainer_info) { ?>
                    <div class="mt-3">
                        <h5 class="text-info">Your Trainer</h5>
                        <p class="mb-0"><strong>Name:</strong> <?= htmlspecialchars($trainer_info['trainer_name']) ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($trainer_info['trainer_email']) ?></p>
                    </div>
                <?php } ?>
            </section>
        </main>
    <?php } ?>

    <?php if($_SESSION['role'] == '4') { ?>
        <main class="container-fluid">
            <section class="bg-light px-5 pb-5">
                <?php if (!empty($plan_info)) { ?>
                    <h4>Plan: <?= htmlspecialchars($plan_info['title']) ?> (₹<?= $plan_info['price'] ?>)</h4>
                <?php } ?>

                <ul>
                <?php foreach ($menu_items as $menu) { ?>
                    <li>
                        <strong><?= htmlspecialchars($menu['name']) ?></strong><br>
                        <?php echo $menu['description'] ? $menu['description'] : ''; ?>
                    </li>
                <?php } ?>
                </ul>
            </section>
        </main>
    <?php } ?>

    <?php if($_SESSION['role'] == '3') { ?>
        <main class="container-fluid">
            <section class="bg-light p-5">
                <?php if ($customers_result->num_rows > 0): ?>
                    <h5 class="mt-4">Tagged Customers</h5>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Sl. No.</th>
                                <th>Name</th>
                                <th>Phone Number</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; while ($row = $customers_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars($row['phone_number']) ?></td>
                                    <td><?= htmlspecialchars($row['email']) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No customers tagged to you yet.</p>
                <?php endif; ?>
            </section>
        </main>
    <?php } ?> 

    <main class="container-fluid">
        
        <section class="row text-center">
             <?php if($_SESSION['role'] == '1') { ?>
            <div class="col-md-4">
                <h4>User Signups</h4>
                <canvas id="lineChart" width="200" height="200"></canvas>
            </div>
            <div class="col-md-4">
                <h4>Membership Plan</h4>
                <canvas id="pieChart" width="200" height="200"></canvas>
            </div>
            <div class="col-md-4">
                <h4>Payment Method</h4>
                <canvas id="barChart" width="200" height="200"></canvas>
            </div>
        </section>

        <section class="row mt-5">
        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>users">
                    <span class="bi bi-people-fill h5"></span>
                    <div class="ml-3">
                        <h5>Users</h5>
                        <p><?php echo $total_users; ?></p>
                    </div>
                </a>
            </article>
        </div>
        
        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>users?status=active">
                    <span class="bi bi-people-fill h5"></span>
                    <div class="ml-3">
                        <h5>Active Users</h5>
                        <p><?php echo $active_users; ?></p>
                    </div>
                </a>
            </article>
        </div>
        
        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>users?status=inactive">
                    <span class="bi bi-people-fill h5"></span>
                    <div class="ml-3">
                        <h5>Inactive Users</h5>
                        <p><?php echo $inactive_users; ?></p>
                    </div>
                </a>
            </article>
        </div>

        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>contact">
                    <span class="bi bi-person-lines-fill h5"></span>
                    <div class="ml-3">
                        <h5>Contact Responses</h5>
                        <p><?php echo $contact_responses; ?></p>
                    </div>
                </a>
            </article>
        </div>
        
        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>trainers">
                    <span class="bi bi-person-lines-fill h5"></span>
                    <div class="ml-3">
                        <h5>Trainers</h5>
                        <p><?php echo $total_trainers; ?></p>
                    </div>
                </a>
            </article>
        </div>

        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>trainers?status=active">
                    <span class="bi bi-person-lines-fill h5"></span>
                    <div class="ml-3">
                        <h5>Active Trainers</h5>
                        <p><?php echo $active_trainers; ?></p>
                    </div>
                </a>
            </article>
        </div>

        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>trainers?status=inactive">
                    <span class="bi bi-person-lines-fill h5"></span>
                    <div class="ml-3">
                        <h5>Inactive Trainers</h5>
                        <p><?php echo $inactive_trainers; ?></p>
                    </div>
                </a>
            </article>
        </div>

        <?php } ?>

        <?php if($_SESSION['role'] == '1' || $_SESSION['role'] == '2') { ?>

        <div class="col-md-6 col-lg-3">
            <article class="p-4 rounded shadow-sm border-left mb-4">
                <a class="d-flex align-items-center" href="<?php echo $base_url; ?>payments">
                    <span class="bi bi-person-lines-fill h5"></span>
                    <div class="ml-3">
                        <h5>Total Payments</h5>
                        <p><?php echo number_format($total_amount, 2); ?></p>
                    </div>
                </a>
            </article>
        </div>

        <?php } ?>
            
        </section>

        
        
        
    </main>
</div>

<?php include 'portal/footer.php'; ?>

<script>
    $(document).ready(function() {
        var userId = '<?php echo $_SESSION['user_id']; ?>'; // Get user ID from session
        if (userId) {
            $.ajax({
                url: 'fetch_subscription_status.php',
                type: 'POST',
                data: {
                    user_id: userId
                }, // Send user_id from session
                success: function(response) {
                    $('#subscription_status').html(response); // Display the response
                }
            });
        } else {
            $('#subscription_status').html('User ID is not available.');
        }
        // Line Chart: User Signups by Month
        const ctxLine = document.getElementById('lineChart').getContext('2d');
        new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($signup_months); ?> , // Dynamic months
                datasets : [{
                    label: 'User Signups',
                    data: <?php echo json_encode($user_signups); ?> , // Dynamic signups
                    borderColor : '#4CAF50',
                    fill: false
                }]
            },
            options: {
                responsive: true
            }
        });
        // Pie Chart: Membership Plan Distribution
        const ctxPie = document.getElementById('pieChart').getContext('2d');
        new Chart(ctxPie, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($plan_names); ?> , // Dynamic plan names
                datasets : [{
                    label: 'Plan Distribution',
                    data: <?php echo json_encode($plan_distribution); ?>
                    , // Dynamic plan distribution data
                    backgroundColor : ['#FF9800', '#4CAF50', '#2196F3']
                }]
            },
            options: {
                responsive: true
            }
        });
        // Bar Chart: Payment Method Distribution (Cash vs Online)
        const ctxBar = document.getElementById('barChart').getContext('2d');
        new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($mode); ?> , // Payment methods (Cash, Online)
                datasets : [{
                    label: 'Total Payment Amount',
                    data: <?php echo json_encode($payment_distribution); ?>
                    , // Total payment amount for each method
                    backgroundColor : ['#FF5722', '#4CAF50'],
                    borderColor: ['#FF5722', '#4CAF50'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true
            }
        });
    });
</script>
