<?php
include 'connection.php';

if (!isset($_GET['id'])) {
    echo "Trainer ID missing.";
    exit;
}

$trainer_id = $_GET['id'];

// Fetch existing data
$sql = "SELECT t.id AS t_id, t.trainer_id, t.description, t.user_id, u.name, u.phone_number 
        FROM trainers t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trainer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows != 1) {
    echo "Trainer not found.";
    exit;
}

$trainer = $result->fetch_assoc();
$trainer_user_id = $trainer['user_id']; // Use user_id for trainer_customers table

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $description = $_POST['description'];
    $selected_ids = isset($_POST['customer_ids']) ? $_POST['customer_ids'] : [];

    if (!empty($description)) {
        $update_sql = "UPDATE trainers SET description = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("si", $description, $trainer_id);

        if ($update_stmt->execute()) {
            // Clear existing trainer-customer relations
            $conn->query("DELETE FROM trainer_customers WHERE trainer_id = $trainer_user_id");

            // Insert new trainer-customer relations
            foreach ($selected_ids as $customer_id) {
                $stmt = $conn->prepare("INSERT INTO trainer_customers (trainer_id, customer_id) VALUES (?, ?)");
                $stmt->bind_param("ii", $trainer_user_id, $customer_id);
                $stmt->execute();
            }

            header("Location: trainers.php?msg=updated");
            exit;
        } else {
            $error = "Update failed: " . $update_stmt->error;
        }
    } else {
        $error = "Invalid description.";
    }
}

// Get list of customers (role = 4) not assigned to other trainers
$customers = $conn->query("
    SELECT id, name FROM users 
    WHERE role = '4' AND id NOT IN (
        SELECT customer_id FROM trainer_customers WHERE trainer_id != $trainer_user_id
    )
");

// Fetch already tagged customers
$selected_customers = [];
$sel_result = $conn->query("SELECT customer_id FROM trainer_customers WHERE trainer_id = $trainer_user_id");
while ($row = $sel_result->fetch_assoc()) {
    $selected_customers[] = $row['customer_id'];
}
?>

<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
    <h4>Edit Trainer</h4>
    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <form method="post">
        <div class="form-group">
            <label>Trainer ID</label>
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($trainer['trainer_id']); ?>" disabled>
        </div>
        <div class="form-group">
            <label>User Name</label>
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($trainer['name']); ?>" disabled>
        </div>
        <div class="form-group">
            <label>Phone Number</label>
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($trainer['phone_number']); ?>" disabled>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="4"><?php echo htmlspecialchars($trainer['description']); ?></textarea>
        </div>
        <div class="form-group">
            <label>Tag Customers</label>
            <select name="customer_ids[]" class="form-control selectpicker" multiple data-live-search="true">
                <?php while ($row = $customers->fetch_assoc()) { ?>
                    <option value="<?= $row['id'] ?>" <?= in_array($row['id'], $selected_customers) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($row['name']) ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update Trainer</button>
        <a href="trainers.php" class="btn btn-secondary">Cancel</a>
    </form>
    </main>
</div>

<?php include 'portal/footer.php'; ?>
