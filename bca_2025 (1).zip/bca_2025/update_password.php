<?php
session_start();
require_once 'connection.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    // Fetch user details first
    $userStmt = $conn->prepare("SELECT email, name FROM users WHERE reset_token = ?");
    $userStmt->bind_param("s", $token);
    $userStmt->execute();
    $userStmt->store_result();
    $userStmt->bind_result($email, $name);
    $userStmt->fetch();
    $userStmt->close();

    // Update password and reset token to NULL
    $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expiry = NULL WHERE reset_token = ?");
    $stmt->bind_param("ss", $new_password, $token);
    $stmt->execute();

    if ($stmt->affected_rows === 1) {
        // Prepare email data
        $emailData = [
            'sender' => ['name' => 'FITNESS CLUB', 'email' => 'thusharshettigar7483@gmail.com'],
            'to' => [['email' => $email, 'name' => $name]],
            'subject' => 'Your Password Has Been Reset Successfully',
            'htmlContent' => "<p>Dear $name,<br><br>Your password has been successfully reset. You can now login with your new password.<br><br>If you did not request this change, please contact us immediately.<br><br>Regards,<br>Fitness Club</p>"
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.brevo.com/v3/smtp/email");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($emailData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'accept: application/json',
            'api-key: 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',
            'content-type: application/json',
        ]);
        $emailResponse = curl_exec($ch);
        $emailHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $emailError = curl_error($ch);
        curl_close($ch);

        // Log email status
        $status = ($emailError || $emailHttpCode >= 400) ? 'failed' : 'sent';
        $type = 'RESET_PASSWORD';
        $logResponse = $emailError ?: $emailResponse;

        $logStmt = $conn->prepare("INSERT INTO email_logs (user_email, user_name, type, status, response) VALUES (?, ?, ?, ?, ?)");
        $logStmt->bind_param("sssss", $email, $name, $type, $status, $logResponse);
        $logStmt->execute();
        $logStmt->close();

        $response = [
            'status' => 'success',
            'message' => 'Password updated successfully.'
        ];
    } else {
        $response = [
            'status' => 'error',
            'message' => 'Failed to update password.'
        ];
    }

    $stmt->close();
    $conn->close();

    echo json_encode($response);
}
?>
