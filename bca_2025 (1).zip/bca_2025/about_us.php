<?php $title = 'About Us'; ?>

<?php include 'header.php'; ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>

<section class="py-5 text-center bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 mx-auto">
            <h1 class="fw-light text-black">It's 'Time' to Join 'Anytime'</h1>
            <p class="lead text-muted text-white">Our mission is to create a supportive and energetic environment that inspires you to push your limits and embrace a healthier and happier life. We believe that fitness is not just about exercise it's a lifestyle.Our platform offer personalized without plans, nutrition advice, and wellness tips to help you stay motivated and make lasting changes. We need to get motivated as well as take part in the fitness-style activities.This platform will provide instructional content such as exercise videos and guides, to help users platform workouts correctly and safely.It also will offer personalized workout program based on individual goal, whether user are aiming for weight loss, muscule gain, general fitness. Health and Fitness information include how to exercise, what to eat and how to get enough sleep. The first thing about fitness start is food. We should take nutritious food, Food rich in protein, vitamins, minerals and carbohydrates is very essential.Good health and fitness are not something which one can achieve entirely on our own. It depends on their physical environment and the quality of food intake.</p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>