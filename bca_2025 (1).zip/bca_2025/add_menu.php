<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $plan = $_POST['plan'];
    $status = $_POST['status'];

    // Insert query
    $insert_sql = "INSERT INTO menu (title, description, sp_id, status) VALUES (?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("ssis", $title, $description, $plan, $status);

    if ($insert_stmt->execute()) {
        $_SESSION['success'] = "Menu added successfully.";
    } else {
        $_SESSION['error'] = "Failed to add menu.";
    }
}
$plans = [];

$result = $conn->query("SELECT id, title, price FROM subscription_plan WHERE status = 'active' ORDER BY price ASC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}
?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h4>Add New Menu</h4>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group mb-3">
                        <label for="title"><strong>Title</strong></label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Select Plan</label>
                    <select name="plan" class="form-control">
                        <option value="">Select</option>
                        <?php foreach ($plans as $plan): ?>
                        <option value="<?= $plan['id']; ?>"
                            data-title="<?= htmlspecialchars($plan['title']); ?>"
                            data-amount="<?= $plan['price']; ?>">
                            <?= htmlspecialchars($plan['title']) . ' - ₹' . $plan['price']; ?>
                        </option>

                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label><strong>Status</strong></label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="active" value="active">
                        <label class="form-check-label" for="active">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="status" id="inactive" value="inactive">
                        <label class="form-check-label" for="inactive">Inactive</label>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                 <div class="col-md-12">
                    <div class="form-group">
                        <label><strong>Description</strong></label>
                        <!-- Create Editor Container -->
                        <div id="editor-container" style="height: 150px;"></div>

                        <!-- Hidden input to store content -->
                        <input type="hidden" name="description" id="description">
                    </div>
                </div>
            </div>
            

            <div class="d-flex justify-content-between mt-4">
                <button type="submit" class="btn btn-success">Add Plan</button>
                <a href="users.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </main>
</div>

<?php include 'portal/footer.php'; ?>

<script>
  // Step 1: Whitelist font sizes
  var Size = Quill.import('attributors/style/size');
  Size.whitelist = ['small', 'normal', 'large', 'huge'];
  Quill.register(Size, true);

  // Step 2: Initialize Quill with font size and your tools
  var quill = new Quill('#editor-container', {
    theme: 'snow',
    modules: {
      toolbar: [
        [{ 'size': ['small', false, 'large', 'huge'] }],  // Font size
        [{ 'align': [] }],                                // Alignment
        ['bold']                                           // Bold
      ]
    }
  });

  // Step 3: Load existing content for edit (if any)
//   var existingContent = <?php // echo json_encode($trainer['description']); ?>;
//   quill.root.innerHTML = existingContent;

  // Step 4: On form submit, copy HTML to hidden input
  document.querySelector("form").onsubmit = function() {
    document.querySelector("#description").value = quill.root.innerHTML;
  };
</script>
