<?php
session_start();
require_once 'connection.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    // Check if user exists
    $stmt = $conn->prepare("SELECT id, name FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($user_id, $name);
        $stmt->fetch();

        // Generate secure token
        $token = bin2hex(openssl_random_pseudo_bytes(32));
        $expiry_time = new DateTime();
        $expiry_time->setTimezone(new DateTimeZone('Asia/Kolkata')); // Set to IST
        $expiry = $expiry_time->modify('+1 hour')->format('Y-m-d H:i:s');        

        // Save token and expiry
        $update = $conn->prepare("UPDATE users SET reset_token = ?, reset_expiry = ? WHERE id = ?");
        $update->bind_param("ssi", $token, $expiry, $user_id);
        $update->execute();

        // Send email
        $reset_link = "http://localhost/bca_2025/reset_password.php?token=$token";

        $emailData = [
            'sender' => ['name' => 'Fitness Club', 'email' => 'thusharshettigar7483@gmail.com'],
            'to' => [['email' => $email, 'name' => $name]],
            'subject' => 'Reset Your Password',
            'htmlContent' => "<p>Hello $name,<br><br>Click the link below to reset your password:<br><a href='$reset_link'>$reset_link</a><br><br>This link is valid for 1 hour.<br><br>Regards,<br>Fitness Club</p>"
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.brevo.com/v3/smtp/email");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($emailData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'accept: application/json',
            'api-key: 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',
            'content-type: application/json',
        ]);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        // Log the email status
        $status = ($curl_error || $http_code >= 400) ? 'failed' : 'sent';
        $responseText = $curl_error ? $curl_error : $response;

        $type = 'RESET_LINK';

        // Insert into email_logs
        $logQuery = "INSERT INTO email_logs (user_email, user_name, type, status, response) 
                    VALUES (?, ?, ?, ?, ?)";
        $logStmt = $conn->prepare($logQuery);
        $logStmt->bind_param("sssss", $email, $name, $type, $status, $responseText);
        $logStmt->execute();
        $logStmt->close();

        $_SESSION['success'] = "Reset email sent to $email. Check your inbox.";
        header("Location: forgot_password");
        exit;
    } else {
        $_SESSION['error'] = "Email not found.";
        header("Location: forgot_password");
        exit;
    }
      
    $stmt->close();
    $conn->close();
}
?>
