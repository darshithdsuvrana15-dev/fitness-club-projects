<?php include 'portal/header.php'; ?>
<?php include 'portal/navigation.php'; ?>

<?php 

if (!isset($_SESSION['user_id'])) {
    echo "User ID missing.";
    exit;
}

$id = $_SESSION['user_id'];  // Assuming the user is logged in and the user ID is stored in session

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];

    // Update profile image if uploaded
    $profile_image = '';  // Default image
    if (!empty($_FILES['profile_image']['name'])) {
        // Handle image upload
        $original_name = basename($_FILES['profile_image']['name']);
        $ext = pathinfo($original_name, PATHINFO_EXTENSION);
        $new_filename = $id . '_' . preg_replace('/[^a-zA-Z0-9]/', '_', pathinfo($original_name, PATHINFO_FILENAME)) . '.' . $ext;
        $target_path = 'assets/images/' . $new_filename;

        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_path)) {
            // Successfully uploaded
            $profile_image = $new_filename;  // Update profile_image variable with the new filename
        } else {
            $_SESSION['error'] = "Image upload failed.";
        }
    }

    // Update the user's profile in the database
    $update_sql = "UPDATE users SET name = ?, profile_image = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssi", $name, $profile_image, $id);

    if ($update_stmt->execute()) {
        $_SESSION['success'] = "Profile updated successfully.";
    } else {
        $_SESSION['error'] = "Profile update failed.";
    }
}

// Fetch the user's current data
$sql = "SELECT id, name, phone_number, email, profile_image, status FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows != 1) {
    echo "User not found.";
    exit;
}

$user = $result->fetch_assoc();
?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <h4>Edit Profile</h4>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="name"><strong>Name</strong></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="phone_number"><strong>Phone Number</strong></label>
                        <input type="text" class="form-control" id="phone_number" value="<?php echo htmlspecialchars($user['phone_number']); ?>" disabled>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="email"><strong>E-Mail</strong></label>
                        <input type="text" class="form-control" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group mb-3">
                        <label for="profile_image"><strong>Profile Image</strong></label><br>
                        <?php if (!empty($user['profile_image'])): ?>
                            <img src="assets/images/<?php echo $user['profile_image']; ?>" alt="Profile Image" class="img-thumbnail" style="max-width: 150px;">
                        <?php else: ?>
                            <p>No image uploaded.</p>
                        <?php endif; ?>
                        <input type="file" name="profile_image" class="form-control mt-3">
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Update Profile</button>
                <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>

    </main>
</div>

<?php include 'portal/footer.php'; ?>
