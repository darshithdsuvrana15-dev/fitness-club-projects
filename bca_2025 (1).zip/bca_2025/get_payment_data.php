<?php
include 'connection.php'; // your DB connection file

$sql = "
    SELECT 
        SUM(CASE WHEN payment_status = 'success' THEN amount ELSE 0 END) AS paid,
        SUM(CASE WHEN payment_status = 'failed' THEN amount ELSE 0 END) AS unpaid
    FROM payments
";

$result = $conn->query($sql);

$data = $result->fetch_assoc();

echo json_encode($data);
?>
