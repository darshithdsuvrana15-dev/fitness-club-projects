<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

        // Prepare SQL to include all fields
        $stmt = $conn->prepare("INSERT INTO contact_form (first_name, last_name,email, subject, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $first_name, $last_name, $email, $subject, $message);

        if ($stmt->execute()) {
            echo "Response Submitted Successfully";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

$conn->close();
?>

