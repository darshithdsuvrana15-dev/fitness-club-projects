<?php
    $host = "localhost";
    $user = "root";
    $password ="";
    $db = "bca_2024_25";

    // Create connection
    $conn = new mysqli($host, $user, $password, $db);

    // Check connection
    /*if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully";*/
?>
