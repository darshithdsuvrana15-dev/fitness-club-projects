<?php
require_once 'dompdf/autoload.inc.php';
include 'connection.php';
include 'amount_to_words.php';
session_start();
use Dompdf\Dompdf;

$user_id = $_SESSION['user_id'];

$name = $_POST['name'];
$phone = $_POST['phone_number'];
$email = $_POST['email'];
$dob = $_POST['dob'] ? $_POST['dob'] : NULL;
$plan = $_POST['plan'];
$amount = $_POST['amount'];
$payment_id = $_POST['payment_id'];
$payment_status = 'success';
$paid_on = date("Y-m-d H:i:s");
$payment_mode = 'ONLINE';

$stmt_plan = $conn->prepare("SELECT price, duration FROM subscription_plan WHERE id = ? AND status = 'active'");
$stmt_plan->bind_param("i", $plan);
$stmt_plan->execute();
$stmt_plan->bind_result($plan_price, $plan_duration);
$stmt_plan->fetch();
$stmt_plan->close();

$invoice_date = date('Y-m-d', strtotime($paid_on));
$start_date = date('Y-m-d');
$end_date = date('Y-m-d', strtotime("+$plan_duration days", strtotime($start_date)));

$stmt1 = $conn->prepare("INSERT INTO payments (user_id, amount, payment_status, payment_id, paid_on, sp_id, end_date, mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt1->bind_param("iissssss", $user_id, $amount, $payment_status, $payment_id, $paid_on, $plan, $end_date, $payment_mode);
$stmt1->execute();

$invoice_id = $stmt1->insert_id;

$invoice_number = "INV-" . str_pad($invoice_id, 6, '0', STR_PAD_LEFT);

$tax_percent = 18;
$tax_amount = ($plan_price * $tax_percent) / (100 + $tax_percent);
$base_price = $plan_price - $tax_amount;
$total_amount = $plan_price;

$amount_words = convertNumberToWords(round($total_amount)) . " only";

$member_no = 'FCM' . $user_id;
$address = 'Mangalore';
$workout_type = 'GYM';
$received_by = 'FITNESS CLUB';
$tax = $tax_percent;

 // ===== Generate PDF Invoice =====
$dompdf = new Dompdf();
ob_start();
include 'invoice_template.php';
$invoiceHtml = ob_get_clean();
$dompdf->loadHtml($invoiceHtml);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$pdfOutput = $dompdf->output();
$pdfBase64 = base64_encode($pdfOutput);

// ===== Send Invoice Email with Attachment =====
$emailData2 = [
    'sender' => ['name' => 'FITNESS CLUB', 'email' => 'thusharshettigar7483@gmail.com'],
    'to' => [['email' => $email, 'name' => $name]],
    'subject' => 'Your Payment Invoice - Fitness Club',
    'htmlContent' => "<p>Dear $name,<br><br>Thank you for your payment. Please find your invoice attached.<br><br>Invoice Number: $invoice_number<br>Invoice Date: $invoice_date<br><br>Regards,<br>Fitness Club</p>",
    'attachment' => [
        [
            'content' => $pdfBase64,
            'name' => "invoice_$invoice_number.pdf"
        ]
    ]
];

$ch2 = curl_init();
curl_setopt($ch2, CURLOPT_URL, "https://api.brevo.com/v3/smtp/email");
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_POST, true);
curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($emailData2));
curl_setopt($ch2, CURLOPT_HTTPHEADER, [
    'accept: application/json',
    'api-key: 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',
    'content-type: application/json',
]);
$response2 = curl_exec($ch2);
$http_code2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
$curl_error2 = curl_error($ch2);
curl_close($ch2);

$status2 = ($curl_error2 || $http_code2 >= 400) ? 'failed' : 'sent';
$responseText2 = $curl_error2 ? $curl_error2 : $response2;
$type2 = 'INVOICE';

$logStmt = $conn->prepare("INSERT INTO email_logs (user_email, user_name, type, status, response) VALUES (?, ?, ?, ?, ?)");
$logStmt->bind_param("sssss", $email, $name, $type2, $status2, $responseText2);
$logStmt->execute();
$logStmt->close();

// Redirect
$_SESSION['thankyou_data'] = [
    'name' => $name,
    'amount' => $amount,
    'payment_id' => $payment_id
];

header("Location: dashboard.php?user_id=$user_id");
exit;

?>
