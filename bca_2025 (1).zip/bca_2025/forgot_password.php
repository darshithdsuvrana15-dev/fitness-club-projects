<?php 
$title = 'Reset Password'; 
session_start(); 
?>
<?php include 'header.php';  ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>

<!-- forgot_password.php -->
<section class="bg-light py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                <h1 class="mb-3">Reset Your Password</h1>
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php
                            echo $_SESSION['error'];
                            unset($_SESSION['error']);
                        ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success">
                        <?php
                            echo $_SESSION['success'];
                            unset($_SESSION['success']);
                        ?>
                    </div>
                <?php endif; ?>
                <form method="POST" action="send_reset_email.php">
                    <div class="row g-3">
                        <div class="col-12">
                            <label for="email" class="form-label">Enter your email address</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-dark w-100 fw-bold">Send Reset Link</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
