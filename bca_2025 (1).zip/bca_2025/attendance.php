<?php
include 'connection.php';

$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$month = isset($_GET['month']) ? $_GET['month'] : date('m');

$members = [];
$res_members = mysqli_query($conn, "SELECT id, name FROM users");
while ($m = mysqli_fetch_assoc($res_members)) {
    $members[$m['id']] = $m['name'];
}

$daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
$dates = [];
for ($d = 1; $d <= $daysInMonth; $d++) {
    $dates[] = sprintf("%04d-%02d-%02d", $year, $month, $d);
}

$attendance = [];
$res = mysqli_query($conn, "
    SELECT * FROM gym_attendance 
    WHERE MONTH(attendance_date) = $month AND YEAR(attendance_date) = $year
");

while ($row = mysqli_fetch_assoc($res)) {
    $attendance[$row['attendance_date']][$row['user_id']] = $row['status'];
}
?>
<?php include 'portal/header.php';  ?>

<?php include 'portal/navigation.php';  ?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">

  <div class="row g-4">
    <div class="col-md-6">
      <form action="mark_attendance.php" method="POST" class="p-4 border rounded shadow-sm bg-light">
        <h5>Mark Attendance</h5>
        <div class="mb-3">
          <label for="user_id" class="form-label">Select Member</label>
          <select name="user_id" class="form-control selectpicker attendance-user" required data-live-search="true">
            <option value="">-- Select --</option>
            <?php
                if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
                    if ($_SESSION['role'] == 3) {
                        // Trainer: show only tagged customers
                        $trainer_id = $_SESSION['user_id'];
                
                        $query = "
                            SELECT u.id, u.name
                            FROM trainer_customers t
                            JOIN users u ON u.id = t.customer_id
                            WHERE t.trainer_id = ?
                        ";
                
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("i", $trainer_id);
                        $stmt->execute();
                        $result = $stmt->get_result();
                
                        while ($user = $result->fetch_assoc()) {
                            echo "<option value='{$user['id']}'>{$user['name']}</option>";
                        }
                
                        $stmt->close();
                
                    } else {
                        // Other roles: show all users
                        $users = mysqli_query($conn, "SELECT id, name FROM users");
                        while ($user = mysqli_fetch_assoc($users)) {
                            echo "<option value='{$user['id']}'>{$user['name']}</option>";
                        }
                    }
                }
            ?>
          </select>

        </div>
        <button type="submit" class="btn btn-primary w-100 attendance-submit" disabled>Mark Attendance</button>

      </form>
    </div>

    <div class="col-md-6">
      <form action="checkout_attendance.php" method="POST" class="p-4 border rounded shadow-sm bg-light">
        <h5>Mark Check-out</h5>
        <div class="mb-3">
          <label for="user_id" class="form-label">Select Member</label>
          <select name="user_id" class="form-control selectpicker attendance-user" required data-live-search="true">
            <option value="">-- Select --</option>
            <?php
                if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
                    if ($_SESSION['role'] == 3) {
                        // Trainer: show only tagged customers
                        $trainer_id = $_SESSION['user_id'];
                
                        $query = "
                            SELECT u.id, u.name
                            FROM trainer_customers t
                            JOIN users u ON u.id = t.customer_id
                            WHERE t.trainer_id = ?
                        ";
                
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("i", $trainer_id);
                        $stmt->execute();
                        $result = $stmt->get_result();
                
                        while ($user = $result->fetch_assoc()) {
                            echo "<option value='{$user['id']}'>{$user['name']}</option>";
                        }
                
                        $stmt->close();
                
                    } else {
                        // Other roles: show all users
                        $users = mysqli_query($conn, "SELECT id, name FROM users");
                        while ($user = mysqli_fetch_assoc($users)) {
                            echo "<option value='{$user['id']}'>{$user['name']}</option>";
                        }
                    }
                }
            ?>
          </select>

        </div>
        <button type="submit" class="btn btn-warning w-100 checkout-submit" disabled>Mark Check-out</button>

      </form>
    </div>
  </div>

  <!-- Filter -->
  <form method="get" class="mt-5 mb-3">
    <div class="row g-2 align-items-end">
      <div class="col-md-4">
        <label class="form-label">Select Month</label>
        <select name="month" class="form-control">
          <?php
          for ($i = 1; $i <= 12; $i++) {
              $selected = ($i == $month) ? 'selected' : '';
              echo "<option value='$i' $selected>" . date('F', mktime(0, 0, 0, $i, 10)) . "</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Select Year</label>
        <select name="year" class="form-control">
          <?php
          $currentYear = date('Y');
          for ($i = $currentYear; $i >= $currentYear - 5; $i--) {
              $selected = ($i == $year) ? 'selected' : '';
              echo "<option value='$i' $selected>$i</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-4">
        <button type="submit" class="btn btn-primary w-100">Submit</button>
      </div>
    </div>
  </form>

  <div class="mb-3">
    <a href="export_attendance.php?<?= http_build_query($_GET) ?>" target="_blank" class="btn btn-success">
      Export to Excel
    </a>
  </div>

  <!-- Attendance Table -->
  <div class="table-responsive">
    <table class="table table-bordered table-striped table-sm text-center align-middle">
      <thead class="table-dark">
        <tr>
          <th>Name</th>
          <?php foreach ($dates as $date): ?>
            <th><?= date('d', strtotime($date)) ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($members as $member_id => $name): ?>
          <tr>
            <td class="text-start"><?= htmlspecialchars($name) ?></td>
            <?php foreach ($dates as $date): ?>
              <td>
                <?= isset($attendance[$date][$member_id]) 
                    ? '<span class="bi bi-check text-success"></span>' 
                    : '<span class="bi bi-x text-danger"></span>' ?>
              </td>

            <?php endforeach; ?>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

            </main>
</div>

<?php include 'portal/footer.php';  ?>

<script>

  function toggleButton(selectElement, buttonClass) {
    const val = $(selectElement).val();
    $(buttonClass).prop('disabled', !val);
  }

  $('.attendance-user').on('change', function () {
    const $form = $(this).closest('form');
    const submitButton = $form.find('button[type="submit"]');
    const val = $(this).val();
    submitButton.prop('disabled', !val);
  });

  // Trigger on page load
  $('.attendance-user').each(function () {
    const $form = $(this).closest('form');
    const submitButton = $form.find('button[type="submit"]');
    const val = $(this).val();
    submitButton.prop('disabled', !val);
  });

</script>

<?php if (isset($_GET['message'])): ?>
<script>
  Swal.fire({
    icon: 'info',
    title: 'Notice',
    text: <?= json_encode($_GET['message']) ?>,
  });
</script>
<?php endif; ?>
