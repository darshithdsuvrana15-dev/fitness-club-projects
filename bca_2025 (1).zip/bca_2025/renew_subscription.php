<?php include 'portal/header.php'; ?>
<?php
include 'connection.php'; // Make sure this connects to DB

$user_id = $_SESSION['user_id'] ? $_SESSION['user_id'] : 0;

// Fetch user details
$userDetails = [];
$query = mysqli_query($conn, "SELECT name, email, phone_number FROM users WHERE id = '$user_id'");
if (mysqli_num_rows($query) > 0) {
    $userDetails = mysqli_fetch_assoc($query);
}


// Fetch existing data
$pay_sql = "SELECT sp_id FROM payments WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$pay_stmt = $conn->prepare($pay_sql);
$pay_stmt->bind_param("i", $user_id);
$pay_stmt->execute();
$pay_result = $pay_stmt->get_result();

$pay = null;
if ($pay_result->num_rows === 0) {
    $_SESSION['error'] = "Plan not found.";
} else {
    $pay = $pay_result->fetch_assoc();
}


$plans = [];


$result = $conn->query("SELECT id, title, price FROM subscription_plan WHERE status = 'active' ORDER BY price ASC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}

?>
<?php include 'portal/navigation.php'; ?>

<div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
        <section class="bg-light p-5">
            <div class="col-md-3">
                <label class="form-label">Plan</label>
                <select name="plan" class="form-control">
                    <option value="">Select Plan</option>
                    <?php foreach ($plans as $plan): ?>
                    <option value="<?= $plan['id']; ?>"
                        data-title="<?= htmlspecialchars($plan['title']); ?>"
                        data-amount="<?= $plan['price']; ?>"
                        <?= ($plan['id'] == $pay['sp_id']) ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($plan['title']) . ' - ₹' . $plan['price']; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <button id="pay-button" class="btn btn-primary mt-4">Renew Subscription</button>
            </div>

            <form id="payment-data-form" action="record_payment.php" method="POST" style="display:none;">
                <input type="hidden" name="user_id" value="<?= $user_id ?>">
                <input type="hidden" name="name">
                <input type="hidden" name="email">
                <input type="hidden" name="phone_number">
                <input type="hidden" name="dob">
                <input type="hidden" name="plan">
                <input type="hidden" name="amount">
                <input type="hidden" name="payment_id" id="payment_id">
            </form>
        </section>
    </main>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    const user = <?= json_encode($userDetails) ?>;

    $('#pay-button').click(function () {
    const selectedPlan = $('select[name="plan"]').find(':selected');
    const planId = selectedPlan.val();
    const planAmount = selectedPlan.data('amount');

   if (!planId) {
    Swal.fire({
        icon: 'warning',
        title: 'Plan Required',
        text: 'Please select a subscription plan to proceed.',
        confirmButtonColor: '#3085d6'
    });
    return;
}


    const amount = planAmount * 100; // in paisa

    const options = {
        key: "rzp_test_tzjjBShSxC3SJC",
        amount: amount,
        currency: "INR",
        name: "FITNESS CLUB",
        image: "https://kumaraswamyvidyalaya.com/images/fitness-club-logo.png",
        description: selectedPlan.data('title') + " Plan Renewal",
        handler: function (response) {
            $('#payment-data-form input[name="name"]').val(user.name);
            $('#payment-data-form input[name="email"]').val(user.email);
            $('#payment-data-form input[name="phone_number"]').val(user.phone_number);
            $('#payment-data-form input[name="dob"]').val(user.dob || '');
            $('#payment-data-form input[name="amount"]').val(planAmount);
            $('#payment-data-form input[name="plan"]').val(planId);
            $('#payment_id').val(response.razorpay_payment_id);
            $('#payment-data-form').submit();
        },
        prefill: {
            name: user.name,
            email: user.email,
            contact: user.phone_number
        },
        theme: {
            color: "#3399cc"
        }
    };

    const rzp = new Razorpay(options);
    rzp.open();
});

</script>

<?php include 'portal/footer.php'; ?>
