<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.5;
            color: #ed1c2454;
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        
        p {
            margin-bottom: 10px;
        }
        
        .contact-info {
            margin-top: 30px;
            font-size: 14px;
        }
        
        .contact-info p {
            margin-bottom: 5px;
        }
        
        .contact-info strong {
            font-weight: bold;
        }
        
        .logo {
            display: block;
            margin-top: 20px;
            text-align: center;
        }
        
        .logo img {
            max-width: 150px;
            height: auto;
        }
        
        .site-link {
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <p>Dear <strong><?= htmlspecialchars($name) ?></strong>,</p>

        <p>Thank you for registering at our gym!.</p>

        <p><strong>Your login credentials:</strong></p>
        <ul>
            <li><strong>Email:</strong> <?= htmlspecialchars($email) ?></li>
            <li><strong>Password:</strong> <?= htmlspecialchars($raw_password) ?></li>
        </ul>

        <p>We want to ensure that you have the best experience with us. If you have any questions or need assistance, feel free to reach out to us at any time.</p>

        <p>If you have any urgent questions, you can contact our support team at <strong><a href="tel:7483145981">+91 7483 145 981</a></strong> or via email at <strong><a href="mailto:info@fitnessclub.com">info@fitnessclub.com</a></strong>.</p>

        <div class="contact-info">
            <p>Best regards,</p>
            <p>Your Fitness Club</p>
        </div>

        <div class="logo">
            <a href="https://fitnessclub.com" target="_blank">
                <img src="https://kumaraswamyvidyalaya.com/images/fitness-club-logo.png" alt="Gym Logo">
            </a>
        </div>

        <div class="site-link">
            <p>Visit our website: <a href="https://fitnessclub.com" target="_blank">https://fitnessclub.com</a></p>
        </div>
    </div>
</body>
</html>
