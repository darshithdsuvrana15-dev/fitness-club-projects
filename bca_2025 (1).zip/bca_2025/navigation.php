<!-- Header Start -->
<header class="site-header position-absolute w-100">
    <nav class="navbar navbar-expand-lg navbar-dark p-3 bg-transparent" id="headerNav">
      <div class="container-fluid">
        <a class="navbar-brand d-block d-lg-none" href="<?php echo $base_url; ?>">
          <img src="<?php echo $base_url; ?>assets/web/images/logo.png" height="140" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    
        <div class=" collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mx-auto d-flex align-items-center">
            <li class="nav-item <?= ($activePage == 'index.php') ? 'active' : ''; ?>">
              <a class="nav-link mx-2" href="<?php echo $base_url; ?>index">Home</a>
            </li>
            <li class="nav-item <?= ($activePage == 'about_us.php') ? 'active' : ''; ?>">
              <a class="nav-link mx-2" href="<?php echo $base_url; ?>about_us">About Us</a>
            </li>
            <li class="nav-item <?= ($activePage == 'programs.php') ? 'active' : ''; ?>">
              <a class="nav-link mx-2" href="<?php echo $base_url; ?>programs">Programs</a>
            </li>
            <li class="nav-item d-none d-lg-block">
              <a class="nav-link mx-2" href="<?php echo $base_url; ?>">
                <img src="<?php echo $base_url; ?>assets/web/images/logo.png" height="140" />
              </a>
            </li>
            <li class="nav-item <?= ($activePage == 'sign_up.php') ? 'active' : ''; ?>">
              <a class="nav-link mx-2" href="<?php echo $base_url; ?>sign_up">Sign Up</a>
            </li>
            <li class="nav-item <?= ($activePage == 'sign_in.php') ? 'active' : ''; ?>">
              <a class="nav-link mx-2" href="<?php echo $base_url; ?>sign_in">Sign In</a>
            </li>
            <li class="nav-item <?= ($activePage == 'contact_us.php') ? 'active' : ''; ?>">
              <a class="nav-link mx-2" href="<?php echo $base_url; ?>contact_us">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
</header>