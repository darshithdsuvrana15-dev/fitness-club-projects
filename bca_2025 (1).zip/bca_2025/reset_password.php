<?php
session_start(); 
require_once 'connection.php';


$token = $_GET['token'] ? $_GET['token'] : '';

$stmt = $conn->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_expiry >= NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 1) {
    ?>

<?php 
    $title = 'Reset Password'; 
?>
<?php include 'header.php';  ?>
<?php include 'navigation.php'; ?>
<?php include 'banner.php'; ?>

<!-- forgot_password.php -->
<section class="bg-light py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                <h1 class="mb-3">Your Password</h1>
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php
                            echo $_SESSION['error'];
                            unset($_SESSION['error']);
                        ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-danger">
                        <?php
                            echo $_SESSION['success'];
                            unset($_SESSION['success']);
                        ?>
                    </div>
                <?php endif; ?>
                <form id="resetPasswordForm" method="POST">
                    <div class="row g-3">
                        <div class="col-12">
                            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                            <label for="email" class="form-label">New Password:</label>
                            <input type="password" class="form-control" name="new_password" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-dark w-100 fw-bold">Update Password</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</section>

<?php
} else {
    $_SESSION['error'] = "Invalid or expired token.";
    header("Location: reset_password");
    exit;
}
$stmt->close();
$conn->close();
?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
document.getElementById('resetPasswordForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('update_password.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        Swal.fire({
            icon: data.status,
            title: data.status === 'success' ? 'Success' : 'Error',
            text: data.message
        });
        // No redirect – keep user on the same page
    });
});
</script>
