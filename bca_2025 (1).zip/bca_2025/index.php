<?php $title = 'Home'; ?>

<?php include 'header.php'; ?>

<?php include 'navigation.php'; ?>

<section  class="main-banner" id="top">
    <video autoplay="" muted="" loop="" id="bg-video">
        <source src="<?php echo $base_url; ?>assets/web/videos/gym-video.mp4" type="video/mp4">
    </video>

    <div class="video-overlay header-text">
        <div class="caption">
            <h6>work harder, get stronger</h6>
            <h2>easy with our <em>gym</em></h2>
            <div class="main-button scroll-to-section">
                <a href="sign_up.php">Become a member</a>
            </div>
        </div>
    </div>
</section>

<section class="py-5 text-center bg-black">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 mx-auto">
            <h1 class="text-white">It's 'Time' to Join 'Anytime'</h1>
            <p class="lead text-white">What makes Anytime Fitness the best gym in India? Anytime Fitness offers a personalized, accessible, and inclusive place for your workout! Offering the opportunity to stay healthy to people from all walks of life, Anytime Fitness offers avant-garde equipment and the latest fitness trends to keep you motivated, no matter your level of fitness.</p>
                <div class="main-button scroll-to-section">
                    <a href="about_us.php">Read More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Include database connection
include('connection.php');

$sql = "SELECT id, title, description, price FROM subscription_plan WHERE status = 'active'";
$result = $conn->query($sql);

$plans = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $plans[] = $row;
    }
}
?>

<section class="py-5">
    <div class="container w-75">
        <h1 class="text-center text-white">Our Gym Plans</h1>
        <p class="text-center mb-5 text-white">Choose the plan that suits your fitness goals and budget.</p>

        <div id="plansCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php 
                $chunks = array_chunk($plans, 3);
                foreach ($chunks as $index => $group): 
                ?>
                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                        <div class="row align-items-center">
                            <?php foreach ($group as $plan): ?>
                                <div class="col-sm-4 mb-4">
                                    <div class="card p-3 shadow-sm p-card">
                                        <h2 class="text-center mt-4"><?php echo $plan['title']; ?></h1>
                                        <div class="card-body text-center">
                                            <?php echo $plan['description']; ?>
                                            <div class="main-button scroll-to-section mt-3">
                                                <a href="sign_up?plan=<?php echo $plan['id']; ?>">Join Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if (count($plans) > 3): ?>
                <!-- Carousel Controls -->
                <button class="carousel-control-prev" type="button" data-bs-target="#plansCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#plansCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            <?php endif; ?>
        </div>
    </div>
</section>



<section class="py-5 bg-black">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="card p-3 border-none border-0 g-cards" style="width: 18rem;">
                    <img src="<?php echo $base_url; ?>assets/web/images/personal_training.jpg" class="card-img-top rounded-3" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">Personal Training</h5>
                        <p class="card-text"> one-on-one coaching designed to help you achieve your unique health,and a personal trainer for indi.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card p-3 border-none border-0 g-cards" style="width: 18rem;">
                    <img src="<?php echo $base_url; ?>assets/web/images/nutrition_image.jpg" class="card-img-top rounded-3" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">Nutrition Classes</h5>
                        <p class="card-text">Our nutrition classes offer practical, science-based guidance to help individuals make informed food.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card p-3 border-none border-0 g-cards" style="width: 18rem;">
                    <img src="<?php echo $base_url; ?>assets/web/images/group_classes.jpg" class="card-img-top rounded-3" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">Group Classes</h5>
                        <p class="card-text">Our group classes are designed to create a motivating, supportive environment where participants can learn.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card p-3 border-none border-0 g-cards" style="width: 18rem;">
                    <img src="<?php echo $base_url; ?>assets/web/images/weight_training.jpg" class="card-img-top rounded-3" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">Weight Classes</h5>
                        <p class="card-text">Our weight classes are designed to help you build strength, increase muscle tone, and improve overall fitness.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Include database connection
include('connection.php');

// SQL query to join the trainers and users table and fetch relevant details
$sql = "SELECT trainers.trainer_id, users.name, users.profile_image, trainers.description
        FROM trainers
        JOIN users ON trainers.user_id = users.id
        WHERE trainers.status = 'active'";

$result = $conn->query($sql);

$trainers = [];
if ($result->num_rows > 0) {
    // Fetch all trainers
    while($row = $result->fetch_assoc()) {
        $trainers[] = $row;
    }
}

// Close connection
$conn->close();
?>

<section class="py-5">
    <div class="container marketing">
        <!-- Bootstrap Carousel -->
        <div id="trainersCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php 
                $chunks = array_chunk($trainers, 3); // Split the trainers into chunks of 3
                foreach ($chunks as $index => $chunk): 
                    $activeClass = $index === 0 ? 'active' : ''; // Make the first chunk active
                ?>
                    <div class="carousel-item <?php echo $activeClass; ?>">
                        <div class="row">
                            <?php foreach ($chunk as $trainer): ?>
                                <div class="col-lg-4 text-center text-white">
                                    <img class="rounded-circle" src="assets/web/images/<?php echo $trainer['profile_image']; ?>" height="140" width="140"/>
                                    <h2><?php echo htmlspecialchars($trainer['name']); ?></h2>
                                    <p><?php echo htmlspecialchars($trainer['description']); ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php if (count($trainers) > 3): ?>
                <!-- Carousel Controls -->
                <button class="carousel-control-prev" type="button" data-bs-target="#plansCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#plansCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            <?php endif; ?>
        </div>
    </div>
</section>


<?php include 'footer.php'; ?>