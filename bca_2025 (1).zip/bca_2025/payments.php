<?php include 'portal/header.php';  ?>
<?php include 'portal/navigation.php';  ?>

<?php

    $mode_filter = isset($_GET['mode']) ? $_GET['mode'] : '';
    $search = isset($_GET['search']) ? $_GET['search'] : '';

    $conditions = [];
    if ($mode_filter !== '') {
        $conditions[] = "mode = '$mode_filter'";
    }
    if ($search) {
        $conditions[] = "payment_id LIKE '%$search%'";
    }
    
    $whereSql = '';
    if (!empty($conditions)) {
        $whereSql = " WHERE " . implode(" AND ", $conditions);
    }

    $sql = "SELECT p.id, p.amount, p.payment_status, p.payment_id, p.paid_on, p.mode, 
            CASE WHEN p.created_by = 0 THEN 'RAZORPAY' ELSE u1.name END AS received_by, 
            u2.name AS payee_name, 
            pl.title 
        FROM payments p 
        LEFT JOIN users u1 ON p.created_by = u1.id 
        LEFT JOIN users u2 ON p.user_id = u2.id
        LEFT JOIN subscription_plan pl ON p.sp_id = pl.id $whereSql";

    $result = $conn->query($sql);

?>



 <div class="col-md-9 col-lg-10 ml-md-auto px-0">
    <main class="container-fluid">
    <form method="GET" class="mb-3">
        <div class="row mb-3">
            <div class="col-md-3">
                <label class="form-label">Search</label>
                <input type="text" name="search" class="form-control" placeholder="Search payment id" value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Mode</label>
                <select name="mode" class="form-control">
                    <option value="">All</option>
                    <option value="CASH" <?= $mode_filter == 'CASH' ? 'selected' : '' ?>>Cash</option>
                    <option value="ONLINE" <?= $mode_filter == 'ONLINE' ? 'selected' : '' ?>>Online</option>
                </select>
            </div>
           
            <div class="col-md-3" style="margin-top: 2rem;">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
        <div class="d-flex justify-content-between">
            <a href="export_payments.php?<?= http_build_query($_GET) ?>" target="_blank" class="btn btn-success">Export to Excel</a>
            <a href="add_payment.php" class="btn btn-secondary">Add New Payment</a>
        </div>
    </form>

<h3 class="d-none d-print-block text-center mb-4">User Report</h3>

    <table class="table table-bordered" id="userTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Payee Name</th>
                <th>Payment ID</th>
                <th>Amount</th>
                <th>Plan</th>
                <th>Status</th>
                <th>Registered At</th>
                <th>Received By</th>
                <th>Mode</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php $i = 1; while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['payee_name']; ?></td>
                        <td><?php echo $row['payment_id']; ?></td>
                        <td><?php echo number_format($row['amount'], 2); ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo $row['payment_status']; ?></td>
                        <td><?php echo date('d M Y', strtotime($row['paid_on'])); ?></td>
                        <td><?php echo $row['received_by']; ?></td>
                        <td><?php echo $row['mode']; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">No payments found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </main>
</div>

<?php include 'portal/footer.php';  ?>
